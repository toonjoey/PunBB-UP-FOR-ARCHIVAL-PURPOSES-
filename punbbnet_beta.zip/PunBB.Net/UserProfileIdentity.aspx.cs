﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;
using System.Globalization;

namespace PunBB
{
    public partial class UserProfileIdentity : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            ErrorBox.Text = "";

            if (IsPostBack == false)
            {
                ProfileCommon UserInfo = GetProfile();
                
                if ((UserInfo.Contact.Email != "") && (UserInfo.UserName != null))
                {
                    Email.Text = UserInfo.Contact.Email;
                    DateFormat.Text = UserInfo.Time.DateFormat;
                    TimeFormat.Text = UserInfo.Time.TimeFormat;
                    TimeZone.Text = UserInfo.Time.TimeZone.ToString();

                    //Show all cultures in drop down list. If forum don't contein languge-pack for selected culture en-EN will be used.

                    string CurrentLanguage = UserInfo.Personal.Language;

                    CultureInfo[] Cultures = System.Globalization.CultureInfo.GetCultures(CultureTypes.SpecificCultures);
                    foreach (CultureInfo Culture in Cultures)
                    {
                        ListItem Item = new ListItem(Culture.EnglishName, Culture.Name);
                        if (Culture.Name == CurrentLanguage)
                            Item.Selected = true;

                        Languages.Items.Add(Item);
                    }
                    
                }

            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string UserName = Membership.GetUserNameByEmail(Email.Text);
            ProfileCommon UserInfo = GetProfile();

            if ((UserName == "") || (UserName == UserInfo.UserName))
            {
                UserInfo.Contact.Email = Email.Text;
            }
            else
            {
                ErrorBox.Text = "Email already used";
                return;
            }

            UserInfo.Time.DateFormat = DateFormat.Text;
            UserInfo.Time.TimeFormat = TimeFormat.Text;
            UserInfo.Time.TimeZone = TimeZone.Text;
            UserInfo.Personal.Language = Languages.Text;
            UserInfo.Save();
        }

        protected ProfileCommon GetProfile()
        {
            ProfileCommon UserInfo = null;
            if ((User.Identity.Name == Request.QueryString["UserName"]) || (Request.QueryString["UserName"] == null))
            {
                UserInfo = Profile;
            }
            else if (User.IsInRole("Moderator"))
            {
                UserInfo = Profile.GetProfile(Request.QueryString["UserName"]);
            }
            else
            {
                Response.Redirect(SiteMap.RootNode.Url);
            }

            return UserInfo;
        }
    }
}