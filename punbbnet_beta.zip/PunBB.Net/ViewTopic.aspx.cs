﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using PunBB.Helpers;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.Odbc;

namespace PunBB
{
    public partial class ViewTopic : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            
            DataSource.ConnectionString = _connection.ConnectionString;
            DataSource.SelectCommand = "SELECT " + Request.QueryString["Topic"] + " AS Topic, Posts.Pid, Users.UserName, Users.Comment, Users.CreationDate, Posts.Message, Posts.Posted, Posts.Edited, Posts.EditedBy FROM Posts LEFT JOIN Users ON Posts.UserId = Users.UserId " +
                " WHERE Posts.Tid =" + Request.QueryString["Topic"] +
                " GROUP BY Users.UserName, Users.IsOnline, Users.Comment, Users.CreationDate, Posts.Message, Posts.Posted, Posts.Edited, Posts.EditedBy,  Posts.Pid" +
                " ORDER BY Posts.Posted";

            if(IsPostBack == false)
                lstPosts.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PostsOnPage"]);

            lstPosts.DataBind();

            TopicActions();
            this.LoadComplete += new EventHandler(ViewTopic_LoadComplete);
        }
        
        protected void ViewTopic_LoadComplete(object sender, EventArgs e)
        {
            
            //HyperLink hlReplyTop = (HyperLink)LoginViewReplyTop.FindControl("ReplyLink");
            HyperLink hlReplyBottom = (HyperLink)LoginViewReplyBottom.FindControl("ReplyLink");
            if (/*hlReplyTop != null &&*/ hlReplyBottom != null)
            {
                //hlReplyTop.NavigateUrl = "~/Post.aspx?Topic=" + Request.QueryString["Topic"] + "&Forum=" + Request.QueryString["Forum"];
                hlReplyBottom.NavigateUrl = "~/Post.aspx?Topic=" + Request.QueryString["Topic"] + "&Forum=" + Request.QueryString["Forum"];
            }
        }
        
        //Delete Post
        protected void PostDelete(object sender, EventArgs e)
        {
            Button Delete = (Button)sender;
            
            OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);
            
            OdbcCommand Cmd = new OdbcCommand("DELETE * FROM Posts WHERE Pid=?", Conn);
            Cmd.Parameters.Add("@Pid", OdbcType.Int).Value = Delete.CommandArgument;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Conn.Close();
                lstPosts.DataBind();
                TopicActions();
            }
        }
        
        //Add or remove actions according to the user's role
        protected void TopicActions()
        {
            if (User.IsInRole("Moderator") == true)
            {
                foreach (TableRow i in lstPosts.Rows)
                {
                    Label Actions = (Label)i.Cells[0].FindControl("PostActions");
                    HiddenField PostId = (HiddenField)i.Cells[0].FindControl("PostId");
                    Actions.Text = "<a href=\"EditPost.aspx?PostId=" + PostId.Value + "&Topic=" + Request.QueryString["Topic"] + "&Forum=" + Request.QueryString["Forum"] + "\">Edit</a>";

                    Button Delete = (Button)i.Cells[0].FindControl("PostDelete");
                    Delete.Visible = true;
                }
            
                hlDeleteTopic.NavigateUrl = "~/DeleteTopic.aspx?Topic=" + Request.QueryString["Topic"] + "&Forum=" + Request.QueryString["Forum"];
            }
            else
            {
                hlDeleteTopic.Visible = false;
            }
        }

    }
}
