﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.Odbc;
using System.Web.Configuration;
using System.Web.Hosting;

namespace PunBB
{
    public partial class DeleteTopic : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.IsInRole("Moderator"))
            {
                _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;

                String Cmd = "SELECT Users.UserName, Topics.Posted, Topics.Subject FROM Users, Topics " +
                    "WHERE Topics.UserId = Users.UserId AND Topics.Tid=" + Request.QueryString["Topic"];

                SqlDataSource Data = new SqlDataSource("System.Data.Odbc", _connection.ConnectionString, Cmd);

                lstTopicToDelete.DataSource = Data;
                lstTopicToDelete.DataBind();
                Cmd = "SELECT Forums.Fname, Topics.Subject, Users.UserName, Topics.Posted " +
                    "FROM Users, Topics, Forums WHERE Forums.Fid=" + Request.QueryString["Forum"] + " AND Topics.UserId= Users.UserId AND Topics.Tid=" + Request.QueryString["Topic"];
                Data = new SqlDataSource("System.Data.Odbc", _connection.ConnectionString, Cmd);
                lstForumInfo.DataSource = Data;
                lstForumInfo.DataBind();
            }
            else
            {
                Response.Redirect("~/ViewTopic.aspx?Topic=" + Request.QueryString["Topic"] + "&Forum=" + Request.QueryString["Forum"]);
            }

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/ViewTopic.aspx?Topic=" + Request.QueryString["Topic"] + "&Forum=" + Request.QueryString["Forum"]);
        }

        protected void btnDeleteTopic_Click(object sender, EventArgs e)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(_connection.ConnectionString);
            OdbcTransaction tran = null;
            OdbcCommand Cmd = new OdbcCommand("DELETE * FROM Posts"+   
                " WHERE Tid = ?", conn);

            Cmd.Parameters.Add("@Tid", OdbcType.Int).Value =Request.QueryString["Topic"]; 
            

            OdbcCommand Cmd2 = new OdbcCommand("DELETE * FROM Topics" +
               " WHERE Tid = ?", conn);

            Cmd2.Parameters.Add("@Tid", OdbcType.Int).Value = Request.QueryString["Topic"];
            


            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                
                Cmd.Transaction = tran;
                Cmd.ExecuteNonQuery();

                Cmd2.Transaction = tran;
                Cmd2.ExecuteNonQuery();

                tran.Commit();
            }
            catch (OdbcException ex)
            {
                tran.Rollback();
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            Response.Redirect("~/ViewForum.aspx?Forum="+Request.QueryString["Forum"]);
        }
}
}