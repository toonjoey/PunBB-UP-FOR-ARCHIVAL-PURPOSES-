﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using PunBB.Providers;
using System.Web.UI.WebControls;
using PunBB.Helpers;
using System.Web.Security;
using System.Threading;

namespace PunBB
{
    public partial class Register : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-US");
            //Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

            #region Localization
            PunRegister.AnswerLabelText = Resources.RegisterResource.AnswerLabelText;
            PunRegister.AnswerRequiredErrorMessage = Resources.RegisterResource.AnswerRequireErrorMsg;
            PunRegister.CancelButtonText = Resources.RegisterResource.CancelButtonText;
            PunRegister.CompleteSuccessText = Resources.RegisterResource.CompleteSuccessText;
            PunRegister.ConfirmPasswordCompareErrorMessage = Resources.RegisterResource.ConfirmPasswordCompareErr;
            PunRegister.ConfirmPasswordLabelText = Resources.RegisterResource.ConfirmPasswordLabelTxt;
            PunRegister.ConfirmPasswordRequiredErrorMessage = Resources.RegisterResource.ConfirmPasswordRequiredErr;
            PunRegister.ContinueButtonText = Resources.RegisterResource.ContinueButtonText;
            PunRegister.CreateUserButtonText = Resources.RegisterResource.CreateUserButtonText;
            PunRegister.DuplicateEmailErrorMessage = Resources.RegisterResource.DuplicateEmailErrMsg;
            PunRegister.DuplicateUserNameErrorMessage = Resources.RegisterResource.DuplicateUsernameErrMsg;
            PunRegister.EmailLabelText = Resources.RegisterResource.EmailLabelText;
            PunRegister.EmailRegularExpressionErrorMessage = Resources.RegisterResource.EmailRegExpErrMsg;
            PunRegister.EmailRequiredErrorMessage = Resources.RegisterResource.EmailRequiredErrMsg;
            PunRegister.FinishPreviousButtonText = Resources.RegisterResource.FinishPrevButtonTxt;
            PunRegister.InvalidAnswerErrorMessage = Resources.RegisterResource.InvalidAnswerErrMsg;
            PunRegister.InvalidEmailErrorMessage = Resources.RegisterResource.InvalidEmailErrMsg;
            PunRegister.InvalidPasswordErrorMessage = Resources.RegisterResource.InvalidPasswordErrMsg;
            PunRegister.InvalidQuestionErrorMessage = Resources.RegisterResource.InvalidQuestionErrMsg;
            PunRegister.PasswordLabelText = Resources.RegisterResource.PasswordLabelText;
            PunRegister.PasswordRegularExpressionErrorMessage = Resources.RegisterResource.PasswordRegExpErr;
            PunRegister.PasswordRequiredErrorMessage = Resources.RegisterResource.PasswordRequiredErrMsg;
            PunRegister.QuestionLabelText = Resources.RegisterResource.QuestionLabelTxt;
            PunRegister.QuestionRequiredErrorMessage = Resources.RegisterResource.QuestionRequiredErrMsg;
            PunRegister.StartNextButtonText = Resources.RegisterResource.StartNextButtonTxt;
            PunRegister.StepPreviousButtonText = Resources.RegisterResource.StepPreviousButtonTxt;
            PunRegister.UnknownErrorMessage = Resources.RegisterResource.UnknownErrMsg;
            PunRegister.UserNameLabelText = Resources.RegisterResource.UserNameLabelTxt;
            PunRegister.UserNameRequiredErrorMessage = Resources.RegisterResource.UserNameRequiredErrMsg;
            #endregion

            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
        }

        protected void PunRegister_CreatedUser(object sender, EventArgs e)
        {
            //System.Globalization.CultureInfo ci = Thread.CurrentThread.CurrentCulture;
            //Thread.CurrentThread.CurrentCulture.NumberFormat.
            //System.Globalization.NumberFormatInfo.CurrentInfo
            Roles.AddUserToRole(PunRegister.UserName, "Member");
            DropDownList TimeZone = (DropDownList)PunRegister.CreateUserStep.ContentTemplateContainer.FindControl("drdownTimeZone");
            DropDownList DateFormat = (DropDownList)PunRegister.CreateUserStep.ContentTemplateContainer.FindControl("drdownDateFormat");
            DropDownList TimeFormat = (DropDownList)PunRegister.CreateUserStep.ContentTemplateContainer.FindControl("drdownTimeFormat");
            PunMembershipProvider provider = new PunMembershipProvider();
            provider.AddUsersCultureInfo(PunRegister.UserName, Convert.ToDouble(TimeZone.SelectedValue, System.Globalization.NumberFormatInfo.CurrentInfo), DateFormat.SelectedValue, TimeFormat.SelectedValue, _connection.ConnectionString);
        }

}
}
