﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using PunBB.Helpers;
using System.Web.UI.WebControls;
using PunBB.Helpers;
using System.Configuration;

namespace PunBB
{
    public partial class ViewForum : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.LoadComplete+=new EventHandler(ViewForum_LoadComplete);
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            ViewForumDataSource.ConnectionString = _connection.ConnectionString;
            string Fid = Request.QueryString["Forum"];
            //ViewForumDataSource.SelectCommand = "SELECT Topics.Tid AS ID, Topics.Subject AS "+Resources.ViewForumResource.Topics+
            //    " , (COUNT(Posts.Pid)-1) AS "+Resources.ViewForumResource.Replies+" , Topics.NumViews AS "+Resources.ViewForumResource.Views+
            //    " , MAX(Posts.Posted) AS "+Resources.ViewForumResource.LastPost+
            //    " From Topics LEFT JOIN Posts ON"+
            //    " Posts.Tid = Topics.Tid"+
            //    " WHERE Topics.Fid = " + Request.QueryString["Forum"]+
            //    " GROUP BY Topics.Subject, Topics.NumViews, Topics.Tid";

            ViewForumDataSource.SelectCommand = "SELECT Topics.Tid, Topics.Subject "+
                " , (COUNT(Posts.Pid)-1) AS Replies"+ //, Topics.NumViews "+
                " , MAX(Posts.Posted) AS LastPost, Users.UserName"+
                " From Users LEFT JOIN(Topics LEFT JOIN Posts ON"+
                " Posts.Tid = Topics.Tid) ON Topics.UserId = Users.UserId"+
                " WHERE Topics.Fid = " + Request.QueryString["Forum"]+
                " GROUP BY Topics.Subject,  Topics.Tid, Users.UserName"; //Topics.NumViews
            lstTopics.Caption = "<div class=\"main-head\"><h2 class=\"hn\"><span><span class=\"item-info\">" + Resources.ViewForumResource.Topics + "</span></span></h2></div><div class=\"main-subhead\"><p class=\"item-summary forum-views\"><span><strong class=\"subject-title\">" + Resources.ViewForumResource.Topic + "</strong> in this forum with details of <strong class=\"info-replies\">" + Resources.ViewForumResource.Replies + "</strong>"/*, <strong class=\"info-views\">views</strong>*/+ ", <strong class=\"info-lastpost\">" + Resources.ViewForumResource.LastPost + "</strong>.</span></p></div>";



            if (IsPostBack == false)
                lstTopics.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["TopicsOnPage"]);
            try
            {
                lstTopics.DataBind();
            }
            catch (Exception ex)
            {
                WriteToEventLog(ex,"Can't bind data");
                Response.Redirect("~/Default.aspx");
            }           
        }

        protected void ViewForum_LoadComplete(object sender, EventArgs e)
        {
            string Fid = Request.QueryString["Forum"];

            //HyperLink hlPostNewTop = (HyperLink)LoginViewPostNewTop.FindControl("HyperLink1");
            HyperLink hlPostNewBottom = (HyperLink)LoginViewPostNewBottom.FindControl("HyperLink2");
            if (/*hlPostNewTop != null && */hlPostNewBottom != null)
            {
                //hlPostNewTop.NavigateUrl = "~/PostNewTopic.aspx?Forum=" + Fid;
                hlPostNewBottom.NavigateUrl = "~/PostNewTopic.aspx?Forum=" + Fid;
            }
        }
        protected void LstTopics_DataBound(object sender, EventArgs e)
        {
            
        }

    }
}