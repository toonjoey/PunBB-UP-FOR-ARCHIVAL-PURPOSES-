﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PunBB.Helpers;
using System.Configuration;
using System.Web.Configuration;
using System.Web.Hosting;
using System.Data.Odbc;
using System.Data;

namespace PunBB
{
    public partial class Default : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            BuildCategoryListView();
        }


        protected void BuildCategoryListView()
        {
            List<String> Categories = GetCategoryList();

            
            if (Categories.Count != 0)
            {
                foreach (String i in Categories)
                {
                    try
                    {
                        //String Cmd = "SELECT Forums.Fid, Forums.FName AS " + Resources.CategoryList.ForumName + ", Forums.Fdesc AS " + Resources.CategoryList.ForumDescription +
                        //             ", COUNT(Topics.Tid) AS " + Resources.CategoryList.TopicsCount + ", SUM(A.PstCount) AS " + Resources.CategoryList.PostsCount +
                        //             " FROM ((Categories LEFT JOIN Forums ON Categories.Cid=Forums.Cid) LEFT JOIN Topics ON Forums.Fid=Topics.Fid)" +
                        //             " LEFT JOIN (SELECT Topics.Tid as TTid, COUNT(Posts.Pid) as PstCount FROM Categories, Forums, Topics,Posts WHERE Categories.Cname='" + i + "'" +
                        //             " And Categories.Cid=Forums.Cid And Topics.Fid=Forums.Fid And Posts.Tid=Topics.Tid GROUP BY Topics.Tid) A ON Topics.Tid=A.TTid " +
                        //             " WHERE Categories.Cname='" + i + "'" +
                        //             " GROUP BY Forums.Fid, Forums.FName, Forums.Fdesc";

                        String Cmd = "SELECT Forums.Fid, Forums.FName, Forums.Fdesc, COUNT(Topics.Tid) AS TopicsCount,"+
                                      "SUM(A.PstCount) AS PostsCount"+
                                     " FROM ((Categories LEFT JOIN Forums ON Categories.Cid=Forums.Cid) LEFT JOIN Topics ON Forums.Fid=Topics.Fid)" +
                                     " LEFT JOIN (SELECT Topics.Tid as TTid, COUNT(Posts.Pid) as PstCount FROM Categories, Forums, Topics,Posts WHERE Categories.Cname='" + i + "'" +
                                     " And Categories.Cid=Forums.Cid And Topics.Fid=Forums.Fid And Posts.Tid=Topics.Tid GROUP BY Topics.Tid) A ON Topics.Tid=A.TTid " +
                                     " WHERE Categories.Cname='" + i + "'" +
                                     " GROUP BY Forums.Fid, Forums.FName, Forums.Fdesc";


                        Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
                        #region Another version of query (may be used in the future)
                        //String Cmd = "SELECT Forums.Fid, Forums.FName AS " + Resources.CategoryList.ForumName +
                        //            ", Forums.Fdesc AS " + Resources.CategoryList.ForumDescription + ", A.TopicsCount AS " + Resources.CategoryList.TopicsCount +
                        //            ", COUNT(Posts.Pid) AS " + Resources.CategoryList.PostsCount +
                        //            " FROM Categories, Forums, Topics, Posts, " +
                        //            "(SELECT COUNT(Topics.Tid)as TopicsCount" +
                        //            " FROM Categories, Forums, Topics WHERE Categories.Cname='" + i + "'" + " And Categories.Cid=Forums.Cid And Topics.Fid=Forums.Fid) A" +
                        //            " WHERE Categories.Cname='" + i + "'" + " And Categories.Cid=Forums.Cid And Topics.Fid=Forums.Fid And Posts.Tid=Topics.Tid" +
                        //            " GROUP BY Forums.Fid, Forums.FName, Forums.Fdesc, A.TopicsCount";
                        #endregion
                        SqlDataSource Data = new SqlDataSource("System.Data.Odbc", _connection.ConnectionString, Cmd);
                        
                        PunBB.PunGridView Category = new PunBB.PunGridView();
                        
                        Category.AutoGenerateColumns = false;
                        
                        foreach (DataControlField Field in MainGridView.Columns)
                            Category.Columns.Add((TemplateField)Field);
                        Category.Caption = " <div class=\"main-head\"><h2 class=\"hn\">" + i + "</span></h2></div><div class=\"main-subhead\"><p class=\"item-summary\"><span><strong class=\"subject-title\">" + Resources.Default.txtForums + "</strong> in this category with details of <strong class=\"info-topics\">" + Resources.Default.txtTopics + "</strong>, <strong class=\"info-posts\">" + Resources.Default.txtPosts + "</strong></span></p></div>";
                        Category.DataSource = Data;
                        Category.DataBind();
                        AddCategoryToPage(Category);
                    }
                    catch(Exception ex) 
                    {
                        
                    }
                 

                }
            }
            
        }

      
        protected void AddCategoryToPage(GridView Data)
        {
            foreach (Control i in this.Master.Controls)
            {
                if (i.ID == "MainForm")
                {
                    foreach (Control j in i.Controls)
                    {
                        if (j.ID == "Content")
                        {
                            j.Controls.Add(Data);
                        }
                    }
                }
            }
        }

        protected List<String> GetCategoryList()
        {
            List<String> Res = new List<String>();

            OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);
            OdbcCommand Cmd = new OdbcCommand("SELECT CName FROM Categories", Conn);
            
            Conn.Open();
            OdbcDataReader Categories = Cmd.ExecuteReader();

            while (Categories.Read())
                Res.Add(Categories.GetString(0));

            return Res;
        }
    }
}