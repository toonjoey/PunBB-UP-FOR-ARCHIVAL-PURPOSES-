﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Configuration;
using System.Web.Configuration;
using System.Web;
using System.Data.Odbc;
using System.Web.Security;
using System.Web.Hosting;
using System.Collections.Generic;

/// <summary>
/// This page collect necessary data and install forum.
/// </summary>
public partial class Install : System.Web.UI.Page
{
    private Dictionary<String, String> InstallInfo;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
        if(Config.AppSettings.Settings["Installed"].Value == "true")
            Response.Redirect(SiteMap.RootNode.Url);
    }

    protected void btnStartInstall_Click(object sender, EventArgs e)
    {
        try
        {
            ErrorBox.Text = "";
            InstallForum();
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            Config.AppSettings.Settings.Add("Installed", "true");
            Config.Save();
        }
        catch (Exception ex)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            Config.AppSettings.Settings.Clear();
            Config.AppSettings.Settings.Add("Installed", "false");
            Config.Save();

            ErrorBox.Text = ex.Message;
        }
        
        if (ErrorBox.Text == "")
            Response.Redirect(SiteMap.RootNode.Url);
    }

    /// <summary>
    /// Install forum.
    /// </summary>
    private void InstallForum()
    {
        InstallInfo = GetInstallInfo();

        ConnectionStringSettings ConnStr = GenerateConnenctionString(InstallInfo["DBType"]);

        #region Add setting into config
        try
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);

            // Clear ConnectionString section and add PunConnectionString
            Config.ConnectionStrings.ConnectionStrings.Clear();
            Config.ConnectionStrings.ConnectionStrings.Add(ConnStr);

            //Add BoardTitel and BoardDescription
            Config.AppSettings.Settings.Clear();
            Config.AppSettings.Settings.Add("BoardTitle", InstallInfo["BoardTitle"]);
            Config.AppSettings.Settings.Add("BoardDescription", InstallInfo["BoardDescription"]);

            //Add TablePrefix
            Config.AppSettings.Settings.Add("TablePrefix", InstallInfo["TablePrefix"]);
			
			//Add some settings
			Config.AppSettings.Settings.Add("ShowAuthorizedUserList", "False");
            Config.AppSettings.Settings.Add("TopicsOnPage", "20");
            Config.AppSettings.Settings.Add("PostsOnPage", "20");
            Config.AppSettings.Settings.Add("MarkForum", "False");
            Config.AppSettings.Settings.Add("MarkTopic", "False");
            Config.AppSettings.Settings.Add("ShowPostCount", "False");
            Config.AppSettings.Settings.Add("AnnouncementEnabled", "False");
            Config.AppSettings.Settings.Add("Announcement", "For more info or help you can visit this <a  href=\"http://punbb.informer.com/forums/\">site</a>");
            Config.AppSettings.Settings.Add("ShowUserInfo", "False");
			
            //Add setting which describes data base type
            string DBType = InstallInfo["DBType"];
            if(DBType.Contains("MySQL"))
                Config.AppSettings.Settings.Add("IsMySQL", "True");
            else
                Config.AppSettings.Settings.Add("IsMySQL", "False");

            // Save config
            Config.Save();
        }
        catch
        {
            throw new Exception("Can not save settings into config file.");
        }
        #endregion

        #region Create tables in database
        try
        {
            FillDataBase(ConnStr.ConnectionString, InstallInfo["TablePrefix"]);
        }
        catch(Exception e)
        {
            throw new Exception("Can not connect to DB." + e.Message);
        }
        #endregion

        #region Create roles
        try
        {
            ((PunBB.Providers.PunRoleProvider)Roles.Provider).UpdateConnectionString();
            Roles.CreateRole("Member");
            Roles.CreateRole("Moderator");
            Roles.CreateRole("Administrator");
        }
        catch(Exception e)
        {
            throw new Exception("Can not create Roles." + e.Message);
        }
        #endregion

        #region Create Administrator
        ((PunBB.Providers.PunMembershipProvider)Membership.Provider).UpdateConnectionString();
        MembershipCreateStatus Status;
        Membership.CreateUser(InstallInfo["AdminUsername"], InstallInfo["AdminPassword"], InstallInfo["AdminEmail"], null, null, true, out Status);

        switch (Status)
        {
            case MembershipCreateStatus.DuplicateEmail:
                throw new Exception("Can not create User. Duplicate email.");
                break;
            case MembershipCreateStatus.DuplicateProviderUserKey:
                throw new Exception("Can not create User. Duplicate provider user key.");
                break;
            case MembershipCreateStatus.DuplicateUserName:
                throw new Exception("Can not create User. Duplicate username.");
                break;
            case MembershipCreateStatus.InvalidAnswer:
                throw new Exception("Can not create User. Invalid answer.");
                break;
            case MembershipCreateStatus.InvalidEmail:
                throw new Exception("Can not create User. Invalid email.");
                break;
            case MembershipCreateStatus.InvalidPassword:
                throw new Exception("Can not create User. Invalid password.");
                break;
            case MembershipCreateStatus.InvalidProviderUserKey:
                throw new Exception("Can not create User. Invalid provider user key.");
                break;
            case MembershipCreateStatus.InvalidQuestion:
                throw new Exception("Can not create User. Invalid question.");
                break;
            case MembershipCreateStatus.InvalidUserName:
                throw new Exception("Can not create User. Invalid username.");
                break;
            case MembershipCreateStatus.ProviderError:
                throw new Exception("Can not create User. Provider error.");
                break;
            case MembershipCreateStatus.UserRejected:
                throw new Exception("Can not create User. User rejected.");
                break;
        }
        
        //Add Administrator into all Roles
        Roles.AddUserToRole(InstallInfo["AdminUsername"], "Member");
        Roles.AddUserToRole(InstallInfo["AdminUsername"], "Moderator");
        Roles.AddUserToRole(InstallInfo["AdminUsername"], "Administrator");
        #endregion
    }

    /// <summary>
    /// This function creates Dirctionary which conteins all neccesary data.
    /// Like DataBase Info, Administrator Info and so on.
    /// </summary>
    /// <returns>Dictionary which conteins all neccesary data.</returns>
    private Dictionary<String, String> GetInstallInfo()
    {
        Dictionary<String, String> Info = new Dictionary<string, string>();

        Info.Add("DBType", DBType.Text);
        Info.Add("DBServer", tbDBServer.Text);
        Info.Add("DBName", tbDBName.Text);
        Info.Add("DBUserName", tbDBUserName.Text);
        Info.Add("DBPassword", tbDBPassword.Text);
        Info.Add("TablePrefix", tbTablePrefix.Text);
        Info.Add("AdminUsername", tbAdmUsername.Text);
        Info.Add("AdminPassword", tbAdmPass.Text);
        Info.Add("AdminEmail", tbAdmEmail.Text);
        Info.Add("BoardTitle", (tbBoardTitle.Text != "") ? tbBoardTitle.Text : "PunBB.NET");
        Info.Add("BoardDescription", (tbBoardDescription.Text != "") ? tbBoardDescription.Text : "Unfortunately no one can be told what PunBB is - you have to see it for yourself.");
        
        return Info;
    }

    /// <summary>
    /// Generate connection string to DataBase.
    /// </summary>
    /// <param name="DBType">DataBase type. Now PunBB.NET supports MS SQL Server, MS Access and MySQL</param>
    /// <returns>Connection string on success or null if somethong is wrong. </returns>
    private ConnectionStringSettings GenerateConnenctionString(String DBType)
    {
        ConnectionStringSettings ConnStr = new ConnectionStringSettings();
        
        ConnStr.Name = "PunConnectionString";

        switch(DBType)
        {
            case "MS Access 2003":
                ConnStr.ConnectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=" + HttpContext.Current.Server.MapPath("~/App_Data/") + InstallInfo["DBServer"] + ";OPTION=133121";
                break;

            case "MySQL ODBC 3.51":
                ConnStr.ConnectionString = "Driver={MySQL ODBC 3.51 Driver};User=" + InstallInfo["DBUserName"] + ";Password=" + InstallInfo["DBPassword"] + ";Server=" + InstallInfo["DBServer"] + ";Option=16834;Database=" + InstallInfo["DBName"];
                break;

            case "MySQL ODBC 5.1":
                ConnStr.ConnectionString = "Driver={MySQL ODBC 5.1 Driver};User=" + InstallInfo["DBUserName"] + ";Password=" + InstallInfo["DBPassword"] + ";Server=" + InstallInfo["DBServer"] + ";Option=16834;Database=" + InstallInfo["DBName"];
                break;

            case "MS SQL Server 2005":
                ConnStr.ConnectionString = "Driver={SQL Native Client};Server=" + InstallInfo["DBServer"] + ";Database=" + InstallInfo["DBName"] + ";uid=" + InstallInfo["DBUserName"] + "; Pwd=" + InstallInfo["DBPassword"];
                break;
            
            default:
                return null;
        }

        ConnStr.ProviderName = "Microsoft.Jet.OLEDB.4.0";
        
        return ConnStr;
    }

    /// <summary>
    /// Creates all the tables in database.
    /// </summary>
    /// <param name="ConnectionString">Connection string used for access to database.</param>
    /// <param name="TablePrefix">DataBase tabel prefix which will be used.</param>
    private void FillDataBase(string ConnectionString, String TablePrefix)
    {
        OdbcConnection Conn = new OdbcConnection(ConnectionString);
        try
        {
            Conn.Open();
            
            #region CreateTables

            #region Posts
            OdbcCommand cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Posts " +
                "(UserId VARCHAR(200), " +
                "Pid INTEGER, " +
                "UserIp VARCHAR(39), " +
                "Message VARCHAR(255), " +
                "HideSmiles INTEGER, " +
                "Posted DATETIME, " +
                "Edited DATETIME, " +
                "EditedBy VARCHAR(200), " +
                "Tid INTEGER, " +
                "PRIMARY KEY (UserId, Pid) )", Conn);

            cmd.ExecuteNonQuery();

            #endregion

            #region Users
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Users " +
                "(UserId VARCHAR(200) NOT NULL, " +
                "UserName VARCHAR (200), " +
                "ApplicationName VARCHAR (100), " +
                "Email VARCHAR (80), " +
                "Comment VARCHAR (255), " +
                "Password VARCHAR (40), " +
                "PasswordQuestion VARCHAR (200), " +
                "PasswordAnswer  VARCHAR (200), " +
                "Salt  VARCHAR (200), " +
                "IsApproved " + OdbcType.Bit + ", " +
                "LastActivityDate DATETIME, " +
                "LastUpdatedDate " + OdbcType.DateTime + ", " +
                "LastLoginDate DATETIME, " +
                "LastPasswordChangeDate DATETIME, " +
                "CreationDate DATETIME, " +
                "IsOnLine " + OdbcType.Bit + ", " +
                "IsLockedOut " + OdbcType.Bit + ", " +
                "LastLockedOutDate DATETIME, " +
                "FailedPasswordAttemptCount INTEGER, " +
                "FailedPasswordAttemptWindowStart DATETIME, " +
                "FailedPasswordAnswerAttemptCount INTEGER, " +
                "FailedPasswordAnswerAttemptWindowStart DATETIME, " +
                "PRIMARY KEY (UserId) )", Conn);

            cmd.ExecuteNonQuery();

            #endregion

            #region Roles
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Roles " +
                "(RoleName VARCHAR(50), " +
                "ApplicationName VARCHAR(100), " +
                "PRIMARY KEY (RoleName, ApplicationName) )", Conn);
            cmd.ExecuteNonQuery();
            #endregion
            
            #region Topics
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Topics " +
                "(UserId VARCHAR(200), " +
                "Tid INTEGER, " +
                "Subject VARCHAR(255), " +
                "Posted DATETIME, " +
                "NumViews INTEGER, " +
                "Closed INTEGER, " +
                "Sticky INTEGER, " +
                "MovedTo INTEGER, " +
                "Fid INTEGER, " +
                "PRIMARY KEY (UserId, Tid))", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region Forums
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Forums " +
                "(Fid INTEGER, " + // AUTO_INCREMENT надо сделать универсально, с помощью ODBC.
                "Fname VARCHAR (80), " +
                "Fdesc VARCHAR (255),"+
                "RedirectUrl VARCHAR (100), " +
                "Moderators VARCHAR (255), " +
                "SortBy INTEGER, " +
                "DispPosition INTEGER, " +
                "Cid INTEGER, " +
                "PRIMARY KEY (Fid) )", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region Reports
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Reports " +
                "(UserId VARCHAR(200), " +
                "Id INTEGER, " +
                "Pid INTEGER, " +
                "Created INTEGER, " +
                "Message VARCHAR (255), " +
                "Zapped INTEGER, " +
                "ZappedBy INTEGER, " +
                "PRIMARY KEY (UserId, Id) )", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region UsersInfo
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "UsersInfo " +
                "(UserId VARCHAR(200) NOT NULL, " +
                "UTitle VARCHAR (200), " +
                "RealName VARCHAR (255), " +
                "URL VARCHAR (80), " +
                "Jabber VARCHAR (80), " +
                "Icq VARCHAR(12), " +
                "Msn VARCHAR(80), " +
                "Aim  VARCHAR(30), " +
                "Yahoo VARCHAR(30), " +
                "Location VARCHAR(30), " +
                "Signature VARCHAR (255), " +
                "DispTopics INTEGER, " +
                "DispPosts INTEGER, " +
                "EmailSetting INTEGER, " +
                "NotifyWithPost INTEGER, " +
                "Autonotify INTEGER, " +
                "ShowSmiles INTEGER, " +
                "ShowImg INTEGER, " +
                "ShowImgSig INTEGER, " +
                "ShowAvatars INTEGER, " +
                "ShowSig INTEGER, " +
                "TimeZone FLOAT, " +
                "Dst INTEGER, " +
                "TimeFormat VARCHAR(20), " +
                "DateFormat VARCHAR(20), " +
                "Language VARCHAR(25), " +
                "Style VARCHAR(25), " +
                "PRIMARY KEY (UserId))", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region Censoring
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Censoring " +
                "(Id INTEGER, " +
                "SearchFor VARCHAR (60), " +
                "ReplaceWith VARCHAR (60), " +
                "PRIMARY KEY (Id) )", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region Categories
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Categories " +
                "(Cid INTEGER NOT NULL, " + // AUTO_INCREMENT надо сделать универсально, с помощью ODBC.
                "Cname VARCHAR (80), " +
                "DispPosition VARCHAR (80), " +
                "Scid INTEGER, " +
                "PRIMARY KEY (Cid) )", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region SearchWords
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "SearchWords " +
                "(Word VARCHAR(20), " +
                "SearchData DATETIME, " +
                "PRIMARY KEY (Word) )", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region UsersInRoles
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "UsersInRoles " +
                "(UserName VARCHAR(200), " +
                "RoleName VARCHAR(50), " +
                "ApplicationName VARCHAR(100), " +
                "PRIMARY KEY (UserName,RoleName, ApplicationName) )", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region SearchMatches
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "SearchMatches " +
                "(Pid INTEGER, " +
                "SubjectMatch VARCHAR (80), " +
                "Word VARCHAR(20), " +
                "UserId INTEGER)", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #region Subscriptions
            cmd = new OdbcCommand("CREATE TABLE " + TablePrefix + "Subscriptions " +
                "(UserId VARCHAR(200), " +
                "Tid INTEGER, " +
                "PRIMARY KEY (UserId) )", Conn);

            cmd.ExecuteNonQuery();
            #endregion

            #endregion
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            Conn.Close();
        }
    }
   
}
