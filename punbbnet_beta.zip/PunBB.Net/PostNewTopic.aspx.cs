﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using PunBB.Helpers;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Security.Principal;
using System.Web.Configuration;
using System.Web.Hosting;
using System.Data.Odbc;

public partial class post : PunBB.PunPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        _extension = new Extension(this);
        _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
        if (!User.Identity.IsAuthenticated)
        {
          Response.Redirect("~/ViewForum.aspx?Forum=" + Request.QueryString["Forum"]);
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string UserName = Page.User.Identity.Name;
        string TopicSubjectText = tbTopicSubject.Text;
        string UserId = string.Empty;
        int CurTopicId = 0;
        int CurPostId = 0;

        if (IsTopicExist(TopicSubjectText, Convert.ToInt32(Request.QueryString["Forum"])) == true)
        {
            ErrorBox.Text = "Subject already exists.";
            return;
        }
        
        Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
        OdbcConnection conn = new OdbcConnection(_connection.ConnectionString);

        #region In this section we get user's Id acording to his name and calculate TopicId fr the topic being created .
        OdbcCommand cmd = new OdbcCommand("SELECT Users.UserId FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +" WHERE UserName = ? ", conn);
        cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = UserName;

        OdbcCommand cmd2 = new OdbcCommand("SELECT MAX(Topics.Tid) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Topics " , conn);

        OdbcCommand cmd3 = new OdbcCommand("SELECT MAX(Posts.Pid) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Posts ", conn);

        OdbcDataReader reader = null;

        try
        {
            conn.Open();

            reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                object Value = reader.GetValue(0);
                if (Value is DBNull)
                {
                    UserId = string.Empty;
                }
                else
                {
                    UserId = Convert.ToString(Value);
                }
            }
            else
            {
                UserId = string.Empty;
            }

            reader = cmd2.ExecuteReader();
            if (reader.HasRows)
            {
                object Value = reader.GetValue(0);
                if (Value is DBNull)
                {
                    CurTopicId = 0;
                }
                else
                {
                    CurTopicId = Convert.ToInt32(Value);
                }
            }
            else
            {
                CurTopicId = 0;
            }

            reader = cmd3.ExecuteReader();
            if (reader.HasRows)
            {
                object Value = reader.GetValue(0);
                if (Value is DBNull)
                {
                    CurPostId = 0;
                }
                else
                {
                    CurPostId = Convert.ToInt32(Value);
                }
            }
            else
            {
                CurPostId = 0;
            }
        }
        catch (OdbcException ex)
        {
            throw ex;
        }
        finally
        {
            if (reader != null)
                reader.Close();
            
            conn.Close();
        }

        #endregion

        #region Insert Values about new Topic into Data Base 
        cmd = new OdbcCommand("INSERT INTO " + Config.AppSettings.Settings["TablePrefix"].Value + "Topics " +
                " (UserId, Tid, Subject, Posted, Fid) " +
                " Values(?, ?, ?, ?, ?)", conn);

        
        cmd.Parameters.Add("@UserId", OdbcType.VarChar, 255).Value = UserId;
        cmd.Parameters.Add("@Tid", OdbcType.Int).Value = CurTopicId+1;
        cmd.Parameters.Add("@Subject", OdbcType.VarChar, 255).Value = TopicSubjectText;
        cmd.Parameters.Add("@Posted", OdbcType.DateTime).Value = System.DateTime.Now ;
        cmd.Parameters.Add("@Fid", OdbcType.Int).Value = Convert.ToInt32(Request.QueryString["Forum"]);



        cmd2 = new OdbcCommand("INSERT INTO " + Config.AppSettings.Settings["TablePrefix"].Value + "Posts " +
                " (UserId, Pid, UserIp, Message, Posted, Edited, EditedBy, Tid) " +
                " Values(?, ?, ?, ?, ?, ?, ?, ?)", conn);


        cmd2.Parameters.Add("@UserId", OdbcType.VarChar, 255).Value = UserId;
        cmd2.Parameters.Add("@Pid", OdbcType.Int).Value = CurPostId+1;
        cmd2.Parameters.Add("@UserIp", OdbcType.VarChar, 255).Value = Request.UserHostAddress.ToString();
        cmd2.Parameters.Add("@Message", OdbcType.VarChar, 255).Value = tbTopicPost.Text;
        cmd2.Parameters.Add("@Posted", OdbcType.DateTime).Value = System.DateTime.Now;
        cmd2.Parameters.Add("@Edited", OdbcType.DateTime).Value = System.DateTime.Now;
        cmd2.Parameters.Add("@EditedBy", OdbcType.VarChar, 255).Value = UserName;
        cmd2.Parameters.Add("@Tid", OdbcType.VarChar, 255).Value = CurTopicId+1;



        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
        }
        catch (OdbcException ex)
        {
            ErrorBox.Text = ex.Message;
        }
        finally
        {
            conn.Close();
        }
        #endregion

        Response.Redirect("~/ViewTopic.aspx?Topic=" + Convert.ToString(CurTopicId + 1) + "&Forum=" + Request.QueryString["Forum"]);
    }

    protected bool IsTopicExist(string TopicName, int ForumId)
    {
        OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);
        OdbcCommand Cmd = new OdbcCommand("SELECT COUNT(*) FROM Topics, Forums WHERE Topics.Subject = ? AND Forums.Fid = ?", Conn);
        Cmd.Parameters.Add("@Subject", OdbcType.VarChar, 255).Value = TopicName;
        Cmd.Parameters.Add("@Fid", OdbcType.Int).Value = ForumId;
        
        int TopicCount = 1;

        try
        {
            Conn.Open();
            TopicCount = (int)Cmd.ExecuteScalar();
        }
        catch (Exception ex)
        {
            ErrorBox.Text = ex.Message;
        }
        finally
        {
            Conn.Close();
        }

        if (TopicCount == 0)
            return false;
        else
            return true;
    }
}
