﻿// Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3 
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;
using System.Web.Hosting;
using PunBB.Helpers;
namespace PunBB
{
    public partial class ProfileMasterPage : PunMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);

            //if (User.IsInRole("Moderator") == false)
                //ProfileMenu.StaticDisplayLevels = 1;
        }
    }
}