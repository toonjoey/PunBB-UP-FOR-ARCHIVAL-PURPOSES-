﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3

using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PunBB.Helpers;
using System.Threading;

namespace PunBB
{
    public partial class Login : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            #region Localization
			//localization is now done inside html markup
			//this section is not really used
            PunLogin.TitleText = Resources.LoginResource.LoginTitleText;
            PunLogin.FailureText = Resources.LoginResource.LoginFailureText;
            PunLogin.LoginButtonText = Resources.LoginResource.LoginButtonText;
            PunLogin.PasswordLabelText = Resources.LoginResource.PasswordLabelText;
            PunLogin.RememberMeText = Resources.LoginResource.RememberMeText;
            PunLogin.UserNameLabelText = Resources.LoginResource.UserNameLabelText;
            PunLogin.UserNameRequiredErrorMessage = Resources.LoginResource.UserNameRequiredError;
            PunLogin.PasswordRequiredErrorMessage = Resources.LoginResource.PasswordRequiredError;
            #endregion
			
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
        }
    }
}