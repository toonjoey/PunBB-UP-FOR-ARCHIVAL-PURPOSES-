﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PunBB.Helpers;
using System.Configuration;
using System.Web.Configuration;
using System.Web.Hosting;

namespace PunBB
{
    public partial class MasterPage : PunBB.PunMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);

            Title.NavigateUrl = SiteMap.RootNode.Url;

            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);

            Title.Text = Config.AppSettings.Settings["BoardTitle"].Value;
            Description.Text = Config.AppSettings.Settings["BoardDescription"].Value;
            if (Convert.ToBoolean(Config.AppSettings.Settings["AnnouncementEnabled"].Value))
                Announcement.Text = Config.AppSettings.Settings["Announcement"].Value;
            else
                AnnouncementPlaceHolder.Visible = false;

        }
}
}