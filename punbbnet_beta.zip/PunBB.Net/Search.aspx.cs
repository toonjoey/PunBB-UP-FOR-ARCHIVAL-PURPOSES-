﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.Configuration;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.Hosting;
using PunBB.Helpers;
using System.Threading;
using System.Web.UI.WebControls.WebParts;

namespace PunBB
{
    public partial class Search : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            //Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-US");
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            DataSource.ConnectionString = _connection.ConnectionString;
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            DataSource.SelectCommand = "SELECT Topics.Subject AS " + Resources.Search.Topic +
                ", Posts.Message AS " + Resources.Search.PostText +
                ", Posts.Posted AS " + Resources.Search.Date +
                ", Users.UserName AS " + "UserName" +
                " FROM Topics,Posts,Users " +
                " WHERE Posts.Message LIKE '%" + tbKeyWords.Text + "%' " +
                " AND Users.UserName LIKE '%" + tbAuthorsName.Text + "%' " +
                " AND Topics.Tid = Posts.Tid AND Posts.UserId = Users.UserId";

            lstMatches.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);

            #region old version of query
            //DataSource.SelectCommand = "SELECT Topics.Subject AS " + Resources.Search.Topic +
            //    ", Posts.Message AS " + Resources.Search.PostText +
            //    ", Posts.Posted AS " + Resources.Search.Date +
            //    " FROM Topics LEFT JOIN Posts ON " +
            //    " Topics.Tid = Posts.Tid " +
            //    " WHERE Posts.Message LIKE '%" + tbKeyWords.Text + "%' " +
            //    " GROUP BY Topics.Subject, Posts.Message, Posts.Posted";
            #endregion

            DataSource.SelectCommand = "SELECT Topics.Subject AS " + Resources.Search.Topic +
                ", Posts.Message AS " + Resources.Search.PostText +
                ", Posts.Posted AS " + Resources.Search.Date +
                ", Users.UserName AS "+"UserName"+
                " FROM Topics,Posts,Users " +
                " WHERE Posts.Message LIKE '%" + tbKeyWords.Text + "%' " +
                " AND Users.UserName LIKE '%" + tbAuthorsName.Text +"%' " +
                " AND Topics.Tid = Posts.Tid AND Posts.UserId = Users.UserId";

            lstMatches.DataBind();
        }
}
}
