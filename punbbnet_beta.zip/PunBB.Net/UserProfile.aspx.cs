﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3

using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;

namespace PunBB
{
    public partial class UserProfile : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;

            foreach (SiteMapNode Node in SiteMap.CurrentNode.ChildNodes)
            {
                int UserNamePos = Node.Url.IndexOf("?UserName=");

                if (UserNamePos != -1)
                    Node.Url = Node.Url.Remove(UserNamePos);
            }

            if (Request.QueryString["UserName"] != null)
            {
                ProfileCommon UserInfo = Profile.GetProfile(Request.QueryString["UserName"]);

                if ((UserInfo.Contact.Email != "") && (UserInfo.UserName != null))
                {
                    foreach (SiteMapNode Node in SiteMap.CurrentNode.ChildNodes)
                    {
                        Node.ReadOnly = false;
                        int UserNamePos = Node.Url.IndexOf("?UserName=");

                        if (UserNamePos != -1)
                            Node.Url = Node.Url.Remove(UserNamePos);

                        Node.Url += "?UserName=" + Request.QueryString["UserName"];
                    }
                }
            }
            
            Response.Redirect(SiteMap.CurrentNode.ChildNodes[0].Url);
        }
    }
}