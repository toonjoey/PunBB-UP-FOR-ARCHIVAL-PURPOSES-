﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;
using System.Data.Odbc;

namespace PunBB
{
    public partial class EditPost : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;

            if (User.IsInRole("Moderator") != true)
                Response.Redirect(SiteMap.RootNode.Url);

            if (IsPostBack == false)
            {
                OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);

                OdbcCommand Cmd = new OdbcCommand("SELECT Message FROM Posts WHERE Pid=?", Conn);
                Cmd.Parameters.Add("@Pid", OdbcType.Int).Value = Request.QueryString["PostId"];

                Conn.Open();

                tbPost.Text = (string)Cmd.ExecuteScalar();

                Conn.Close();
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);

            OdbcCommand Cmd = new OdbcCommand("UPDATE Posts SET Message=?, Edited=?, EditedBy=? WHERE Pid=?", Conn);

            Cmd.Parameters.Add("@Message", OdbcType.VarChar, 255).Value = tbPost.Text;
            Cmd.Parameters.Add("@Edited", OdbcType.DateTime).Value = DateTime.Now;
            Cmd.Parameters.Add("@EditedBy", OdbcType.VarChar, 200).Value = User.Identity.Name;
            Cmd.Parameters.Add("@Pid", OdbcType.Int).Value = Request.QueryString["PostId"];
            
            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ErrorBox.Text = ex.Message;
            }
            finally
            {
                Conn.Close();
            }

            Response.Redirect("ViewTopic.aspx?Topic=" + Request.QueryString["Topic"] + "&Forum=" + Request.QueryString["Forum"]);
        }
    }
}