﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using PunBB.Helpers;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.Odbc;
using System.Web.Hosting;
using System.Web.Configuration;

namespace PunBB
{
    public partial class UserList : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            DataSource.ConnectionString = _connection.ConnectionString;

            DataSource.SelectCommand = "SELECT Users.UserName , Users.Comment, COUNT(Posts.Pid) AS Posts, Users.CreationDate " +
                " FROM Users LEFT JOIN Posts ON " +
                " Users.UserId = Posts.UserId " +
                " GROUP BY Users.UserName, Users.CreationDate, Users.Comment";

            lstUsers.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DataSource.SelectCommand = "SELECT Users.UserName, Users.Comment, COUNT(Posts.Pid) AS Posts, Users.CreationDate"+
                " FROM Users LEFT JOIN Posts ON " +
                " Users.UserId = Posts.UserId " +
                " WHERE Users.UserName LIKE '%" + txtSearch.Text + "%' " +
                " GROUP BY Users.UserName, Users.CreationDate, Users.Comment";

            lstUsers.DataBind();
        }
    }
}
