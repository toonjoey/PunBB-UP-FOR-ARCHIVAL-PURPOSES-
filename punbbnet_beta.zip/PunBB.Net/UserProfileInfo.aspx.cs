﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;
using System.Data.Odbc;

namespace PunBB
{
    public partial class UserProfileInfo : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;

            if (Request.QueryString["UserName"] != null)
            {
                ProfileCommon UserInfo = Profile.GetProfile(Request.QueryString["UserName"]);

                if ((UserInfo.Contact.Email != "") && (UserInfo.UserName != null))
                {
                    FillForm(UserInfo);
                }
                else
                {
                    Response.Redirect(SiteMap.RootNode.Url);
                }
            }
            else
            {
                if(Profile.IsAnonymous == false)
                    FillForm(Profile);
                else
                    Response.Redirect(SiteMap.RootNode.Url);
            }
            
            //ChangePassLink.NavigateUrl = "~/UserProfilePassword.aspx";
        }

        protected void FillForm(ProfileCommon userinfo)
        {
            UserName.Text = userinfo.UserName;
            UserTitle.Text = userinfo.Forum.Title;

            From.Text = userinfo.Personal.Location;

            if (From.Text == "")
                FromField.Visible = false;

            Registered.Text = (Profile.IsAnonymous == false) ? userinfo.Personal.Registered.ToString(Profile.Time.DateFormat) : userinfo.Personal.Registered.ToString("MM/dd/yy");

            //Get PostsNumber
            OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);
            OdbcCommand Cmd = new OdbcCommand("SELECT COUNT(Posts.Pid) FROM Posts LEFT JOIN Users ON Posts.UserId = Users.UserId WHERE Users.UserName = ?", Conn);

            Cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = userinfo.UserName;
            Conn.Open();
            Posts.Text = Convert.ToString(Cmd.ExecuteScalar());

            Conn.Close();

            WebsiteLink.Text = userinfo.Contact.Url;
            WebsiteLink.NavigateUrl = userinfo.Contact.Url;

            if (WebsiteLink.Text == "")
            {
                WebsiteField.Visible = false;
                ContactInfo.Visible = false;
            }

            PostsTopicsGroup.Visible = false;


            EmailTo.Text = userinfo.Contact.Email;
            EmailTo.NavigateUrl = "mailto:" + userinfo.Contact.Email;

        }
    }
}