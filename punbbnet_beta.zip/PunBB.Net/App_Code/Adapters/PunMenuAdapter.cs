﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.Adapters;
using System.Web.UI.WebControls.Adapters;

namespace PunBB
{
    public class PunMenuAdapter : System.Web.UI.WebControls.Adapters.MenuAdapter
    {
        protected override void RenderBeginTag(HtmlTextWriter writer)
        {
            writer.Write("<ul>");
        }
        
        protected override void RenderEndTag(HtmlTextWriter writer)
        {
            writer.Write("</ul>");
        }
        
        protected override void RenderItem(HtmlTextWriter writer, MenuItem item, int position)
        {
            writer.WriteLine("<li><a href=\"" + item.NavigateUrl + "\">" + item.Text + "</a></li>");
        }
    }
}