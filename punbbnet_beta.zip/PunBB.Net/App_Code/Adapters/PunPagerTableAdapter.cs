//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace PunBB
{
    public class PunPagerTableAdapter : System.Web.UI.WebControls.Adapters.WebControlAdapter
    {
        protected override void RenderBeginTag(HtmlTextWriter writer)
        { 
            writer.Write("<div id=\"brd-pagepost-bottom\" class=\"main-pagepost gen-content\">");
            writer.Write(" <p class=\"paging\"><span class=\"pages\">Pages</span>");
        }

        protected override void RenderEndTag(HtmlTextWriter writer) 
        {
            writer.Write("</p></div>");
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            Table PagerTable = (Table)this.Control;
            foreach (TableCell Cell in PagerTable.Rows[0].Cells)
                Cell.RenderControl(writer);   
        }
    }
}