﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.Adapters;
using System.Web.UI.WebControls.Adapters;

namespace PunBB
{
    public class PunGridViewAdapter : System.Web.UI.WebControls.Adapters.DataBoundControlAdapter
    {
        protected override void RenderBeginTag(HtmlTextWriter writer)
        {
        }
        
        protected override void RenderContents(HtmlTextWriter writer)
        {
            GridView Grid = (GridView)this.Control;
            if (Grid.BottomPagerRow != null)
            {
                Grid.BottomPagerRow.RenderControl(writer);
            }

            writer.Write(Grid.Caption);
            
            writer.Write("<div class=\"main-content\">");
            
            foreach (GridViewRow Row in Grid.Rows)
                Row.RenderControl(writer);
            
            writer.Write("</div>");

         
        }
        
        protected override void RenderEndTag(HtmlTextWriter writer)
        {
        }
    }
}