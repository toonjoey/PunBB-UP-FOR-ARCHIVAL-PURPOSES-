﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;

namespace PunBB.Providers
{
    public class PunSiteMapProvider : XmlSiteMapProvider
    {
        private Dictionary<SiteMapNode, SiteMapNodeCollection> _addNode = new Dictionary<SiteMapNode, SiteMapNodeCollection>();
        
        public override SiteMapNodeCollection GetChildNodes(SiteMapNode node)
        {
            SiteMapNodeCollection ret = new SiteMapNodeCollection();

            foreach (SiteMapNode i in base.GetChildNodes(node))
            {
                if (this.IsAccessibleToUser(HttpContext.Current, i))
                {
                    ret.Add(i);
                }
            }

            if (_addNode.ContainsKey(node) == true)
            {
                foreach (SiteMapNode j in _addNode[node])
                {
                    if (this.IsAccessibleToUser(HttpContext.Current, j))
                    {
                        ret.Add(j);
                    }
                }
            }
            return ret;
        }
        
        public void AddCustomNode(SiteMapNode node, SiteMapNode parentNode)
        {
            if (_addNode.ContainsKey(parentNode) == true)
                _addNode[parentNode].Add(node);
            else
                _addNode.Add(parentNode, new SiteMapNodeCollection(node));
        }
        
        public override bool IsAccessibleToUser(System.Web.HttpContext context, System.Web.SiteMapNode node)
        {
            if (node.Roles.Count != 0) 
            {
                foreach (object i in node.Roles)
                    if (context.User.IsInRole(i.ToString()))
                        return true;
            }
            else
            {
                return true;
            }

            return false;
        }
    }
}