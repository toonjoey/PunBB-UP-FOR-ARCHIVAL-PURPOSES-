﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Configuration.Provider;
using System.Data;
using System.Data.Odbc;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Configuration;
using System.Web.Hosting;
using System.Web.Security;

namespace PunBB.Providers
{
    
    public sealed partial class PunMembershipProvider : MembershipProvider
    {
        private int newPasswordLength = 8;
        private string eventSource = "PunMembershipProvider";
        private string eventLog = "Application";
        private string exceptionMessage = "An exception occurred. Please check the Event Log.";
        private string connectionString;


        private MachineKeySection machineKey;


        private bool pWriteExceptionsToEventLog;

        public bool WriteExceptionsToEventLog
        {
            get { return pWriteExceptionsToEventLog; }
            set { pWriteExceptionsToEventLog = value; }
        }

        public override void Initialize(string name, NameValueCollection config)
        {

            if (config == null)
                throw new ArgumentNullException("config");

            if (name == null || name.Length == 0)
                name = "PunMembershipProvider";

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "Pun Membership provider");
            }

            base.Initialize(name, config);

            pApplicationName = GetConfigValue(config["applicationName"],
                                            System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath);
            pMaxInvalidPasswordAttempts = Convert.ToInt32(GetConfigValue(config["maxInvalidPasswordAttempts"], "5"));
            pPasswordAttemptWindow = Convert.ToInt32(GetConfigValue(config["passwordAttemptWindow"], "10"));
            pMinRequiredNonAlphanumericCharacters = Convert.ToInt32(GetConfigValue(config["minRequiredNonAlphanumericCharacters"], "3"));
            pMinRequiredPasswordLength = Convert.ToInt32(GetConfigValue(config["minRequiredPasswordLength"], "7"));
            pPasswordStrengthRegularExpression = Convert.ToString(GetConfigValue(config["passwordStrengthRegularExpression"], ""));
            pEnablePasswordReset = Convert.ToBoolean(GetConfigValue(config["enablePasswordReset"], "true"));
            pEnablePasswordRetrieval = Convert.ToBoolean(GetConfigValue(config["enablePasswordRetrieval"], "true"));
            pRequiresQuestionAndAnswer = Convert.ToBoolean(GetConfigValue(config["requiresQuestionAndAnswer"], "false"));
            pRequiresUniqueEmail = Convert.ToBoolean(GetConfigValue(config["requiresUniqueEmail"], "true"));
            pWriteExceptionsToEventLog = Convert.ToBoolean(GetConfigValue(config["writeExceptionsToEventLog"], "true"));

            string temp_format = config["passwordFormat"];
            if (temp_format == null)
            {
                temp_format = "Hashed";
            }

            switch (temp_format)
            {
                case "Hashed":
                    pPasswordFormat = MembershipPasswordFormat.Hashed;
                    break;
                case "Encrypted":
                    pPasswordFormat = MembershipPasswordFormat.Encrypted;
                    break;
                case "Clear":
                    pPasswordFormat = MembershipPasswordFormat.Clear;
                    break;
                default:
                    throw new ProviderException("Password format not supported.");
            }

            ConnectionStringSettings ConnectionStringSettings =
              ConfigurationManager.ConnectionStrings[config["connectionStringName"]];

            if (ConnectionStringSettings == null || ConnectionStringSettings.ConnectionString.Trim() == "")
            {
                throw new ProviderException("Connection string cannot be blank.");
            }

            connectionString = ConnectionStringSettings.ConnectionString;


            Configuration cfg =
              WebConfigurationManager.OpenWebConfiguration(System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath);
            machineKey = (MachineKeySection)cfg.GetSection("system.web/machineKey");

        }


        public void UpdateConnectionString()
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            connectionString = Config.ConnectionStrings.ConnectionStrings["PunConnectionString"].ConnectionString;
        }

        private string GetConfigValue(string configValue, string defaultValue)
        {
            if (String.IsNullOrEmpty(configValue))
                return defaultValue;
            
            return configValue;
        }


        private string pApplicationName;
        private bool pEnablePasswordReset;
        private bool pEnablePasswordRetrieval;
        private bool pRequiresQuestionAndAnswer;
        private bool pRequiresUniqueEmail;
        private int pMaxInvalidPasswordAttempts;
        private int pPasswordAttemptWindow;
        private MembershipPasswordFormat pPasswordFormat;

        public override string ApplicationName
        {
            get { return pApplicationName; }
            set { pApplicationName = value; }
        }

        public override bool EnablePasswordReset
        {
            get { return pEnablePasswordReset; }
        }


        public override bool EnablePasswordRetrieval
        {
            get { return pEnablePasswordRetrieval; }
        }


        public override bool RequiresQuestionAndAnswer
        {
            get { return pRequiresQuestionAndAnswer; }
        }


        public override bool RequiresUniqueEmail
        {
            get { return pRequiresUniqueEmail; }
        }


        public override int MaxInvalidPasswordAttempts
        {
            get { return pMaxInvalidPasswordAttempts; }
        }


        public override int PasswordAttemptWindow
        {
            get { return pPasswordAttemptWindow; }
        }


        public override MembershipPasswordFormat PasswordFormat
        {
            get { return pPasswordFormat; }
        }

        private int pMinRequiredNonAlphanumericCharacters;

        public override int MinRequiredNonAlphanumericCharacters
        {
            get { return pMinRequiredNonAlphanumericCharacters; }
        }

        private int pMinRequiredPasswordLength;

        public override int MinRequiredPasswordLength
        {
            get { return pMinRequiredPasswordLength; }
        }

        private string pPasswordStrengthRegularExpression;

        public override string PasswordStrengthRegularExpression
        {
            get { return pPasswordStrengthRegularExpression; }
        }

        public override bool ChangePassword(string username, string oldPwd, string newPwd)
        {
            if (!ValidateUser(username, oldPwd))
                return false;


            ValidatePasswordEventArgs args =
              new ValidatePasswordEventArgs(username, newPwd, true);

            OnValidatingPassword(args);

            if (args.Cancel)
                if (args.FailureInformation != null)
                    throw args.FailureInformation;
                else
                    throw new MembershipPasswordException("Change password canceled due to new password validation failure.");

            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("UPDATE "+ Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                    " SET Password = ?, Salt = ?, LastPasswordChangeDate = ? " +
                    " WHERE UserName = ? AND ApplicationName = ?", conn);

            string key = Convert.ToBase64String(GenerateKey());
            cmd.Parameters.Add("@Password", OdbcType.VarChar, 40).Value = EncodePassword(newPwd,key);
            cmd.Parameters.Add("@Salt", OdbcType.VarChar, 200).Value = key;
            cmd.Parameters.Add("@LastPasswordChangeDate", OdbcType.DateTime).Value = DateTime.Now;
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;


            int rowsAffected = 0;

            try
            {
                conn.Open();

                rowsAffected = cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "ChangePassword");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            if (rowsAffected > 0)
            {
                return true;
            }

            return false;
        }

        public override bool ChangePasswordQuestionAndAnswer(string username,
                      string password,
                      string newPwdQuestion,
                      string newPwdAnswer)
        {
            if (!ValidateUser(username, password))
                return false;
            
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                    " SET PasswordQuestion = ?, PasswordAnswer = ?" +
                    " WHERE UserName = ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@PasswordQuestion", OdbcType.VarChar, 200).Value = newPwdQuestion;
            string key = Convert.ToBase64String(GenerateKey());
            cmd.Parameters.Add("@PasswordAnswer", OdbcType.VarChar, 200).Value = EncodePassword(newPwdAnswer,key);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;


            int rowsAffected = 0;

            try
            {
                conn.Open();

                rowsAffected = cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "ChangePasswordQuestionAndAnswer");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            if (rowsAffected > 0)
            {
                return true;
            }

            return false;
        }


        private byte[] GenerateKey()
        {
            byte[] secretkey = new Byte[64];
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            rng.GetBytes(secretkey);
            return secretkey;
        }

        public override MembershipUser CreateUser(string username,
                 string password,
                 string email,
                 string passwordQuestion,
                 string passwordAnswer,
                 bool isApproved,
                 object providerUserKey,
                 out MembershipCreateStatus status)
        {
            ValidatePasswordEventArgs args =
              new ValidatePasswordEventArgs(username, password, true);

            OnValidatingPassword(args);

            if (args.Cancel)
            {
                status = MembershipCreateStatus.InvalidPassword;
                return null;
            }



            if (RequiresUniqueEmail && GetUserNameByEmail(email) != "")
            {
                status = MembershipCreateStatus.DuplicateEmail;
                return null;
            }

            Regex passwordRegEx = new Regex(@"\W");
            MatchCollection SpecificSymbols = passwordRegEx.Matches(password);
            if ((password.Length <MinRequiredPasswordLength) || SpecificSymbols.Count < MinRequiredNonAlphanumericCharacters)
            {
                status = MembershipCreateStatus.InvalidPassword;
                return null;
            }


            MembershipUser u = GetUser(username, false);

            if (u == null)
            {
                DateTime createDate = DateTime.Now;

                if (providerUserKey == null)
                {
                    providerUserKey = Guid.NewGuid();
                }
                else
                {
                    if (!(providerUserKey is Guid))
                    {
                        status = MembershipCreateStatus.InvalidProviderUserKey;
                        return null;
                    }
                }
                
                Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
                OdbcConnection conn = new OdbcConnection(connectionString);
                OdbcCommand cmd = new OdbcCommand("INSERT INTO " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                      " (UserId, UserName, ApplicationName, Email, Comment, Password," +
                      " PasswordQuestion, PasswordAnswer, Salt, IsApproved, " +
                      "  LastActivityDate, LastLoginDate, LastPasswordChangeDate,CreationDate, " +
                      "  IsLockedOut, LastLockedOutDate," +
                      " FailedPasswordAttemptCount, FailedPasswordAttemptWindowStart, " +
                      " FailedPasswordAnswerAttemptCount, FailedPasswordAnswerAttemptWindowStart)" +
                      " Values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)", conn);

                cmd.Parameters.Add("@UserId", OdbcType.VarChar, 200).Value = "{" + providerUserKey.ToString() + "}";
                cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;

                cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;
                
                cmd.Parameters.Add("@Email", OdbcType.VarChar, 80).Value = email;

                cmd.Parameters.Add("@Comment", OdbcType.VarChar, 255).Value = "";

                string key = Convert.ToBase64String(GenerateKey());
                cmd.Parameters.Add("@Password", OdbcType.VarChar, 40).Value = EncodePassword(password, key);
                
                if (RequiresQuestionAndAnswer)
                {
                    cmd.Parameters.Add("@PasswordQuestion", OdbcType.VarChar, 200).Value = passwordQuestion;
                    cmd.Parameters.Add("@PasswordAnswer", OdbcType.VarChar, 200).Value = passwordAnswer;
                }
                else
                {
                    cmd.Parameters.Add("@PasswordQuestion", OdbcType.VarChar, 200).Value = DBNull.Value;
                    cmd.Parameters.Add("@PasswordAnswer", OdbcType.VarChar, 200).Value = DBNull.Value;
                }
                cmd.Parameters.Add("@Salt", OdbcType.VarChar, 200).Value = key;
                cmd.Parameters.Add("@IsApproved", OdbcType.Bit).Value = isApproved;
                cmd.Parameters.Add("@LastActivityDate", OdbcType.DateTime).Value = createDate;
                cmd.Parameters.Add("@LastLoginDate", OdbcType.DateTime).Value = DBNull.Value;
                cmd.Parameters.Add("@LastPasswordChangeDate", OdbcType.DateTime).Value = createDate;
                cmd.Parameters.Add("@CreationDate", OdbcType.DateTime).Value = createDate;
                cmd.Parameters.Add("@IsLockedOut", OdbcType.Bit).Value = false;
                cmd.Parameters.Add("@LastLockedOutDate", OdbcType.DateTime).Value = createDate;
                cmd.Parameters.Add("@FailedPasswordAttemptCount", OdbcType.Int).Value = 0;
                cmd.Parameters.Add("@FailedPasswordAttemptWindowStart", OdbcType.DateTime).Value = createDate;
                cmd.Parameters.Add("@FailedPasswordAnswerAttemptCount", OdbcType.Int).Value = 0;
                cmd.Parameters.Add("@FailedPasswordAnswerAttemptWindowStart", OdbcType.DateTime).Value = createDate;

                try
                {
                    conn.Open();
                
                    int recAdded = cmd.ExecuteNonQuery();

                    if (recAdded > 0)
                    {
                        status = MembershipCreateStatus.Success;
                    }
                    else
                    {
                        status = MembershipCreateStatus.UserRejected;
                    }
                }
                catch (OdbcException e)
                {
                    if (WriteExceptionsToEventLog)
                    {
                        WriteToEventLog(e, "CreateUser");
                    }

                    status = MembershipCreateStatus.ProviderError;
                }
                finally
                {
                    conn.Close();
                }


                return GetUser(username, false);
            }
            else
            {
                status = MembershipCreateStatus.DuplicateUserName;
            }


            return null;
        }


        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("DELETE FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                    " WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@Username", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;
            
            OdbcCommand RetrieveId = new OdbcCommand("SELECT UserId FROM Users WHERE Username = ?", conn);
            RetrieveId.Parameters.Add("@Username", OdbcType.VarChar, 200).Value = username;
                    
            int rowsAffected = 0;

            try
            {
                conn.Open();
                
                if (deleteAllRelatedData)
                {
                    String UID = (String)RetrieveId.ExecuteScalar();
                    
                    RetrieveId = new OdbcCommand("DELETE * FROM Posts WHERE UserId = ?", conn);
                    RetrieveId.Parameters.Add("@UserId", OdbcType.VarChar, 200).Value = UID;
                    
                    RetrieveId.ExecuteNonQuery();
                }

                rowsAffected = cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "DeleteUser");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            if (rowsAffected > 0)
                return true;

            return false;
        }



        public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Count(*) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                              "WHERE ApplicationName = ?", conn);
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = ApplicationName;

            MembershipUserCollection users = new MembershipUserCollection();

            OdbcDataReader reader = null;
            totalRecords = 0;

            try
            {
                conn.Open();
                totalRecords = Convert.ToInt32(cmd.ExecuteScalar());

                if (totalRecords <= 0) { return users; }

                cmd.CommandText = "SELECT UserId, Username, Email, PasswordQuestion," +
                         " Comment, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
                         " LastActivityDate, LastPasswordChangeDate, LastLockedOutDate " +
                         " FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                         " WHERE ApplicationName = ? " +
                         " ORDER BY UserName Asc";

                reader = cmd.ExecuteReader();

                int counter = 0;
                int startIndex = pageSize * pageIndex;
                int endIndex = startIndex + pageSize - 1;

                while (reader.Read())
                {
                    if (counter >= startIndex)
                    {
                        MembershipUser u = GetUserFromReader(reader);
                        users.Add(u);
                    }

                    if (counter >= endIndex) { cmd.Cancel(); }

                    counter++;
                }
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "GetAllUsers ");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                conn.Close();
            }

            return users;
        }


        public override int GetNumberOfUsersOnline()
        {

            TimeSpan onlineSpan = new TimeSpan(0, System.Web.Security.Membership.UserIsOnlineTimeWindow, 0);
            DateTime compareTime = DateTime.Now.Subtract(onlineSpan);

            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Count(*) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                    " WHERE LastActivityDate > ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@CompareDate", OdbcType.DateTime).Value = compareTime;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

            int numOnline = 0;

            try
            {
                conn.Open();

                numOnline = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "GetNumberOfUsersOnline");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return numOnline;
        }



        public override string GetPassword(string username, string answer)
        {
            if (!EnablePasswordRetrieval)
            {
                throw new ProviderException("Password Retrieval Not Enabled.");
            }

            if (PasswordFormat == MembershipPasswordFormat.Hashed)
            {
                throw new ProviderException("Cannot retrieve Hashed passwords.");
            }

            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Password, PasswordAnswer, IsLockedOut FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                  " WHERE UserName = ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

            string password = "";
            string passwordAnswer = "";
            OdbcDataReader reader = null;

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();

                    if (reader.GetBoolean(2))
                        throw new MembershipPasswordException("The supplied user is locked out.");

                    password = reader.GetString(0);
                    passwordAnswer = reader.GetString(1);
                }
                else
                {
                    throw new MembershipPasswordException("The supplied user name is not found.");
                }
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "GetPassword");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                conn.Close();
            }


            if (RequiresQuestionAndAnswer /*&& !CheckPassword(answer, passwordAnswer)*/)//!!!!!!!!!!!!!!!!!!!!!!!!!!!
            {
                UpdateFailureCount(username, "passwordAnswer");

                throw new MembershipPasswordException("Incorrect password answer.");
            }


            if (PasswordFormat == MembershipPasswordFormat.Encrypted)
            {
                password = UnEncodePassword(password);
            }

            return password;
        }


        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT UserId, UserName, ApplicationName, Email, Comment," +
                 " PasswordQuestion, isApproved, LastActivityDate,IsLockedOut, LastLockedOutDate, LastLoginDate," +
                 "  LastPasswordChangeDate, CreationDate" +
                 " FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users WHERE UserName = ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

            MembershipUser u = null;
            OdbcDataReader reader = null;

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader();
                
                if (reader.HasRows)
                {
                    reader.Read();
                    u = GetUserFromReader(reader);

                    if (userIsOnline)
                    {
                        OdbcCommand updateCmd = new OdbcCommand("UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                  "SET LastActivityDate = ? " +
                                  "WHERE Username = ? AND Applicationname = ?", conn);

                        updateCmd.Parameters.Add("@LastActivityDate", OdbcType.DateTime).Value = DateTime.Now;
                        updateCmd.Parameters.Add("@Username", OdbcType.VarChar, 200).Value = username;
                        updateCmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

                        updateCmd.ExecuteNonQuery();
                    }
                }

            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "GetUser(String, Boolean)");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }

                conn.Close();
            }

            return u;
        }



        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT UserId, UserName, Email, PasswordQuestion," +
                  " Comment, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
                  " LastActivityDate, LastPasswordChangeDate, LastLockedOutDate" +
                  " FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users WHERE PKID = ?", conn);

            cmd.Parameters.Add("@PKID", OdbcType.UniqueIdentifier).Value = providerUserKey;

            MembershipUser u = null;
            OdbcDataReader reader = null;

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read();
                    u = GetUserFromReader(reader);

                    if (userIsOnline)
                    {
                        OdbcCommand updateCmd = new OdbcCommand("UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                  "SET LastActivityDate = ? " +
                                  "WHERE PKID = ?", conn);

                        updateCmd.Parameters.Add("@LastActivityDate", OdbcType.DateTime).Value = DateTime.Now;
                        updateCmd.Parameters.Add("@PKID", OdbcType.UniqueIdentifier).Value = providerUserKey;

                        updateCmd.ExecuteNonQuery();
                    }
                }

            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "GetUser(Object, Boolean)");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }

                conn.Close();
            }

            return u;
        }


       

        private MembershipUser GetUserFromReader(OdbcDataReader reader)
        {
            Dictionary<string, object> Reader = new Dictionary<string, object>();

            for (int i = 0; i < reader.FieldCount; i++)
                Reader.Add(reader.GetName(i).ToLower(), reader.GetValue(i));

            object providerUserKey = Reader["userid"];
            string username = Reader["username"].ToString();
            string email = Reader["email"].ToString();

            string passwordQuestion = "";
            if (Reader["passwordquestion"] != DBNull.Value)
                passwordQuestion = Reader["passwordquestion"].ToString();

            string comment = "";
            if (Reader["comment"] != DBNull.Value)
                comment = Reader["comment"].ToString();

            bool isApproved = (Boolean)Reader["isapproved"];
            bool isLockedOut = (Boolean)Reader["islockedout"];
            DateTime creationDate = (DateTime)Reader["creationdate"];

            DateTime lastLoginDate = new DateTime();
            if (Reader["lastlogindate"] != DBNull.Value)
                lastLoginDate = (DateTime)Reader["lastlogindate"];

            DateTime lastActivityDate = (DateTime)Reader["lastactivitydate"];
            DateTime lastPasswordChangedDate = (DateTime)Reader["lastpasswordchangedate"];

            DateTime lastLockedOutDate = new DateTime();
            if (Reader["lastlockedoutdate"] != DBNull.Value)
                lastLockedOutDate = (DateTime)Reader["lastlockedoutdate"];

            MembershipUser u = new MembershipUser(this.Name,
                                                  username,
                                                  providerUserKey,
                                                  email,
                                                  passwordQuestion,
                                                  comment,
                                                  isApproved,
                                                  isLockedOut,
                                                  creationDate,
                                                  lastLoginDate,
                                                  lastActivityDate,
                                                  lastPasswordChangedDate,
                                                  lastLockedOutDate);

            return u;
        }


       

        public override bool UnlockUser(string username)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                              " SET IsLockedOut = False, LastLockedOutDate = ? " +
                                              " WHERE UserName = ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@LastLockedOutDate", OdbcType.DateTime).Value = DateTime.Now;
            cmd.Parameters.Add("@Username", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

            int rowsAffected = 0;

            try
            {
                conn.Open();

                rowsAffected = cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "UnlockUser");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            if (rowsAffected > 0)
                return true;

            return false;
        }


        public override string GetUserNameByEmail(string email)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Username" +
                  " FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users WHERE Email = ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@Email", OdbcType.VarChar, 80).Value = email;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

            string username = "";

            try
            {
                conn.Open();

                username = (string)cmd.ExecuteScalar();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "GetUserNameByEmail");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            if (username == null)
                username = "";

            return username;
        }




      
        public override string ResetPassword(string username, string answer)
        {
            if (!EnablePasswordReset)
            {
                throw new NotSupportedException("Password reset is not enabled.");
            }

            if (answer == null && RequiresQuestionAndAnswer)
            {
                UpdateFailureCount(username, "passwordAnswer");

                throw new ProviderException("Password answer required for password reset.");
            }

            string newPassword =
              System.Web.Security.Membership.GeneratePassword(newPasswordLength, MinRequiredNonAlphanumericCharacters);


            ValidatePasswordEventArgs args =
              new ValidatePasswordEventArgs(username, newPassword, true);

            OnValidatingPassword(args);

            if (args.Cancel)
                if (args.FailureInformation != null)
                    throw args.FailureInformation;
                else
                    throw new MembershipPasswordException("Reset password canceled due to password validation failure.");

            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT PasswordAnswer, IsLockedOut FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                  " WHERE UserName = ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

            int rowsAffected = 0;
            string passwordAnswer = "";
            OdbcDataReader reader = null;

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();

                    if (reader.GetBoolean(1))
                        throw new MembershipPasswordException("The supplied user is locked out.");

                    passwordAnswer = reader.GetString(0);
                }
                else
                {
                    throw new MembershipPasswordException("The supplied user name is not found.");
                }

                if (RequiresQuestionAndAnswer /*&& !CheckPassword(answer, passwordAnswer)*/)//!!!!!!!!!!!!!!!!!!!!
                {
                    UpdateFailureCount(username, "passwordAnswer");

                    throw new MembershipPasswordException("Incorrect password answer.");
                }

                OdbcCommand updateCmd = new OdbcCommand("UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                    " SET Password = ?, LastPasswordChangeDate = ?" +
                    " WHERE UserName = ? AND ApplicationName = ? AND IsLockedOut = False", conn);

                string key = Convert.ToBase64String(GenerateKey());
                updateCmd.Parameters.Add("@Password", OdbcType.VarChar, 40).Value = EncodePassword(newPassword,key);
                updateCmd.Parameters.Add("@LastPasswordChangeDate", OdbcType.DateTime).Value = DateTime.Now;
                updateCmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
                updateCmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

                rowsAffected = updateCmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "ResetPassword");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                conn.Close();
            }

            if (rowsAffected > 0)
            {
                return newPassword;
            }
            else
            {
                throw new MembershipPasswordException("User not found, or user is locked out. Password not Reset.");
            }
        }


        public override void UpdateUser(MembershipUser user)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                    " SET Email = ?, Comment = ?," +
                    " IsApproved = ?" +
                    " WHERE UserName = ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@Email", OdbcType.VarChar, 80).Value = user.Email;
            cmd.Parameters.Add("@Comment", OdbcType.VarChar, 255).Value = user.Comment;
            cmd.Parameters.Add("@IsApproved", OdbcType.Bit).Value = user.IsApproved;
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = user.UserName;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;


            try
            {
                conn.Open();

                cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "UpdateUser");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }
        }

    
        public void AddUsersCultureInfo(string username, double timezone, string datefromat, string timefromat, string connectionString)
        {
            OdbcConnection conn = new OdbcConnection(connectionString);
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);



            #region Getting User Id
            string UserId = string.Empty;
            OdbcCommand cmd = new OdbcCommand("SELECT UserId FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users WHERE UserName = ?", conn);

            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;

            OdbcDataReader reader = null;

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();

                    UserId = reader.GetString(0);
                }
                else
                {
                    throw new MembershipPasswordException("The supplied user name is not found.");
                }
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "ResetPassword");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                conn.Close();
            }
            #endregion


            cmd = new OdbcCommand("INSERT INTO " + Config.AppSettings.Settings["TablePrefix"].Value + "UsersInfo " +
                    " (UserId,TimeZone, DateFormat, TimeFormat)" +
                    " values(?,?,?,?)", conn);

            cmd.Parameters.Add("@UserId", OdbcType.VarChar, 200).Value = UserId;
            cmd.Parameters.Add("@TimeZone", OdbcType.Double).Value = timezone;
            cmd.Parameters.Add("@DateFormat", OdbcType.VarChar, 20).Value = datefromat;
            cmd.Parameters.Add("@TimeFormat", OdbcType.VarChar, 20).Value = timefromat;
           
            try
            {
                conn.Open();

                cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "AddUserInfo");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }
        }
   
     

        public override bool ValidateUser(string username, string password)
        {
            bool isValid = false;

            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Password, Salt, IsApproved FROM  " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                    " WHERE UserName = ? AND ApplicationName = ? AND IsLockedOut = ?", conn);

            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;
            cmd.Parameters.Add("@IsLockedOut", OdbcType.Bit).Value = false;

            OdbcDataReader reader = null;
            bool isApproved = false;
            string pwd = String.Empty;
            string key = String.Empty;

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();
                    pwd = reader.GetString(0);
                    key = reader.GetString(1);
                    isApproved = reader.GetBoolean(2);
                }
                else
                {
                    return false;
                }

                reader.Close();

                if (CheckPassword(password, pwd,key))
                {
                    if (isApproved)
                    {
                        isValid = true;

                        OdbcCommand updateCmd = new OdbcCommand("UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users SET LastLoginDate = ?" +
                                                                " WHERE UserName = ? AND ApplicationName = ?", conn);

                        updateCmd.Parameters.Add("@LastLoginDate", OdbcType.DateTime).Value = DateTime.Now;
                        updateCmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
                        updateCmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

                        updateCmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    conn.Close();

                    UpdateFailureCount(username, "password");
                }
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "ValidateUser");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                conn.Close();
            }

            return isValid;
        }


        private void UpdateFailureCount(string username, string failureType)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT FailedPasswordAttemptCount, " +
                                              "  FailedPasswordAttemptWindowStart, " +
                                              "  FailedPasswordAnswerAttemptCount, " +
                                              "  FailedPasswordAnswerAttemptWindowStart " +
                                              "  FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                              "  WHERE UserName = ? AND ApplicationName = ?", conn);

            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

            OdbcDataReader reader = null;
            DateTime windowStart = new DateTime();
            int failureCount = 0;

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();

                    if (failureType == "password")
                    {
                        failureCount = reader.GetInt32(0);
                        windowStart = reader.GetDateTime(1);
                    }

                    if (failureType == "passwordAnswer")
                    {
                        failureCount = reader.GetInt32(2);
                        windowStart = reader.GetDateTime(3);
                    }
                }

                reader.Close();

                DateTime windowEnd = windowStart.AddMinutes(PasswordAttemptWindow);

                if (failureCount == 0 || DateTime.Now > windowEnd)
                {
                     if (failureType == "password")
                        cmd.CommandText = "UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                          "  SET FailedPasswordAttemptCount = ?, " +
                                          "      FailedPasswordAttemptWindowStart = ? " +
                                          "  WHERE UserName = ? AND ApplicationName = ?";

                    if (failureType == "passwordAnswer")
                        cmd.CommandText = "UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                          "  SET FailedPasswordAnswerAttemptCount = ?, " +
                                          "      FailedPasswordAnswerAttemptWindowStart = ? " +
                                          "  WHERE UserName = ? AND ApplicationName = ?";

                    cmd.Parameters.Clear();

                    cmd.Parameters.Add("@Count", OdbcType.Int).Value = 1;
                    cmd.Parameters.Add("@WindowStart", OdbcType.DateTime).Value = DateTime.Now;
                    cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
                    cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

                    if (cmd.ExecuteNonQuery() < 0)
                        throw new ProviderException("Unable to update failure count and window start.");
                }
                else
                {
                    if (failureCount++ >= MaxInvalidPasswordAttempts)
                    {

                        cmd.CommandText = "UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                          "  SET IsLockedOut = ?, LastLockedOutDate = ? " +
                                          "  WHERE Username = ? AND ApplicationName = ?";

                        cmd.Parameters.Clear();

                        cmd.Parameters.Add("@IsLockedOut", OdbcType.Bit).Value = true;
                        cmd.Parameters.Add("@LastLockedOutDate", OdbcType.DateTime).Value = DateTime.Now;
                        cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
                        cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

                        if (cmd.ExecuteNonQuery() < 0)
                            throw new ProviderException("Unable to lock out user.");
                    }
                    else
                    {
  
                        if (failureType == "password")
                            cmd.CommandText = "UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                              "  SET FailedPasswordAttemptCount = ?" +
                                              "  WHERE UserName = ? AND ApplicationName = ?";

                        if (failureType == "passwordAnswer")
                            cmd.CommandText = "UPDATE " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                              "  SET FailedPasswordAnswerAttemptCount = ?" +
                                              "  WHERE UserName = ? AND ApplicationName = ?";

                        cmd.Parameters.Clear();

                        cmd.Parameters.Add("@Count", OdbcType.Int).Value = failureCount;
                        cmd.Parameters.Add("@UserName", OdbcType.VarChar, 200).Value = username;
                        cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

                        if (cmd.ExecuteNonQuery() < 0)
                            throw new ProviderException("Unable to update failure count.");
                    }
                }
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "UpdateFailureCount");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                conn.Close();
            }
        }



        private bool CheckPassword(string password, string dbpassword, string key)
        {
            string pass1 = password;
            string pass2 = dbpassword;

            switch (PasswordFormat)
            {
                case MembershipPasswordFormat.Encrypted:
                    pass2 = UnEncodePassword(dbpassword);
                    break;
                case MembershipPasswordFormat.Hashed:
                    pass1 = EncodePassword(password,key);
                    break;
                default:
                    break;
            }

            if (pass1 == pass2)
            {
                return true;
            }

            return false;
        }


    

        private string EncodePassword(string password, string salt)
        {
            string encodedPassword = password;

            switch (PasswordFormat)
            {
                case MembershipPasswordFormat.Clear:
                    break;
                case MembershipPasswordFormat.Encrypted:
                    encodedPassword =
                      Convert.ToBase64String(EncryptPassword(Encoding.Unicode.GetBytes(password)));
                    break;
                case MembershipPasswordFormat.Hashed:
                    byte[] s = Encoding.Unicode.GetBytes(salt);
                    HMACSHA1 hash = new HMACSHA1( Encoding.Unicode.GetBytes(salt));
                    //hash.Key = HexToByte(machineKey.ValidationKey);
                    encodedPassword =
                      Convert.ToBase64String(hash.ComputeHash(Encoding.Unicode.GetBytes(password)));
                    break;
                default:
                    throw new ProviderException("Unsupported password format.");
            }

            return encodedPassword;
        }



        private string UnEncodePassword(string encodedPassword)
        {
            string password = encodedPassword;

            switch (PasswordFormat)
            {
                case MembershipPasswordFormat.Clear:
                    break;
                case MembershipPasswordFormat.Encrypted:
                    password =
                      Encoding.Unicode.GetString(DecryptPassword(Convert.FromBase64String(password)));
                    break;
                case MembershipPasswordFormat.Hashed:
                    throw new ProviderException("Cannot unencode a hashed password.");
                default:
                    throw new ProviderException("Unsupported password format.");
            }

            return password;
        }

   

        private byte[] HexToByte(string hexString)
        {
            byte[] returnBytes = new byte[hexString.Length / 2];
            for (int i = 0; i < returnBytes.Length; i++)
                returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            return returnBytes;
        }


  
        public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Count(*) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                      "WHERE UserName LIKE ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UsernameSearch", OdbcType.VarChar, 200).Value = usernameToMatch;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = pApplicationName;

            MembershipUserCollection users = new MembershipUserCollection();

            OdbcDataReader reader = null;

            try
            {
                conn.Open();
                totalRecords = Convert.ToInt32(cmd.ExecuteScalar());

                if (totalRecords <= 0) { return users; }

                cmd.CommandText = "SELECT UserId, Username, Email, PasswordQuestion," +
                  " Comment, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
                  " LastActivityDate, LastPasswordChangeDate, LastLockedOutDate " +
                  " FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                  " WHERE UserName LIKE ? AND ApplicationName = ? " +
                  " ORDER BY UserName Asc";

                reader = cmd.ExecuteReader();

                int counter = 0;
                int startIndex = pageSize * pageIndex;
                int endIndex = startIndex + pageSize - 1;

                while (reader.Read())
                {
                    if (counter >= startIndex)
                    {
                        MembershipUser u = GetUserFromReader(reader);
                        users.Add(u);
                    }

                    if (counter >= endIndex) { cmd.Cancel(); }

                    counter++;
                }
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "FindUsersByName");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }

                conn.Close();
            }

            return users;
        }

     

        public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Count(*) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                                              "WHERE Email LIKE ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@EmailSearch", OdbcType.VarChar, 80).Value = emailToMatch;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 100).Value = ApplicationName;

            MembershipUserCollection users = new MembershipUserCollection();

            OdbcDataReader reader = null;
            totalRecords = 0;

            try
            {
                conn.Open();
                totalRecords = Convert.ToInt32(cmd.ExecuteScalar());

                if (totalRecords <= 0) { return users; }

                cmd.CommandText = "SELECT UserId, UserName, Email, PasswordQuestion," +
                         " Comment, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
                         " LastActivityDate, LastPasswordChangeDate, LastLockedOutDate " +
                         " FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +
                         " WHERE Email LIKE ? AND ApplicationName = ? " +
                         " ORDER BY Username Asc";

                reader = cmd.ExecuteReader();

                int counter = 0;
                int startIndex = pageSize * pageIndex;
                int endIndex = startIndex + pageSize - 1;

                while (reader.Read())
                {
                    if (counter >= startIndex)
                    {
                        MembershipUser u = GetUserFromReader(reader);
                        users.Add(u);
                    }

                    if (counter >= endIndex) { cmd.Cancel(); }

                    counter++;
                }
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "FindUsersByEmail");

                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }

                conn.Close();
            }

            return users;
        }


        private void WriteToEventLog(Exception e, string action)
        {
            EventLog log = new EventLog();
            log.Source = eventSource;
            log.Log = eventLog;

            string message = "An exception occurred communicating with the data source.\n\n";
            message += "Action: " + action + "\n\n";
            message += "Exception: " + e.ToString();

            log.WriteEntry(message);
            
        }

    }
}