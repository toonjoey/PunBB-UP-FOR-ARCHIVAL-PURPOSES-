﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System.Web.Profile;
using System.Configuration.Provider;
using System.Collections.Specialized;
using System;
using System.Data;
using System.Data.Odbc;
using System.Configuration;
using System.Diagnostics;
using System.Web;
using System.Collections;

namespace PunBB.Providers
{

    public sealed class PunProfileProvider : ProfileProvider
    {
        private string eventSource = "PunProfileProvider";
        private string eventLog = "Application";
        private string exceptionMessage = "An exception occurred. Please check the event log.";
        private string connectionString;

        private bool pWriteExceptionsToEventLog;

        public bool WriteExceptionsToEventLog
        {
            get { return pWriteExceptionsToEventLog; }
            set { pWriteExceptionsToEventLog = value; }
        }

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            if (name == null || name.Length == 0)
                name = "PunProfileProvider";

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "Pun Profile provider");
            }

            base.Initialize(name, config);


            if (config["applicationName"] == null || config["applicationName"].Trim() == "")
            {
                pApplicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            }
            else
            {
                pApplicationName = config["applicationName"];
            }

            ConnectionStringSettings pConnectionStringSettings = ConfigurationManager.
                ConnectionStrings[config["connectionStringName"]];

            if (pConnectionStringSettings == null ||
                pConnectionStringSettings.ConnectionString.Trim() == "")
            {
                throw new ProviderException("Connection string cannot be blank.");
            }

            connectionString = pConnectionStringSettings.ConnectionString;
        }


        private string pApplicationName;

        public override string ApplicationName
        {
            get { return pApplicationName; }
            set { pApplicationName = value; }
        }

        public override SettingsPropertyValueCollection GetPropertyValues(SettingsContext context, SettingsPropertyCollection ppc)

        {
            
            string username = (string)context["UserName"];
            bool isAuthenticated = (bool)context["IsAuthenticated"];

            if (username == null)
                throw new Exception("User's name is null");
            
            SettingsPropertyValueCollection svc =
                new SettingsPropertyValueCollection();

            foreach (SettingsProperty prop in ppc)
            {
                SettingsPropertyValue pv = new SettingsPropertyValue(prop);

                switch (prop.Name)
                {
                    case "Personal.Location":
                        pv.PropertyValue = GetLocation(username, isAuthenticated);
                        break;
                    case "Personal.Language":
                        pv.PropertyValue = GetLanguage(username, isAuthenticated);
                        break;
                    case "Personal.Registered":
                        pv.PropertyValue = GetRegistered(username, isAuthenticated);
                        break;
                    case "Personal.RealName":
                        pv.PropertyValue = GetRealName(username, isAuthenticated);
                        break;
                    case "Personal.Signature":
                        pv.PropertyValue = GetSignature(username, isAuthenticated);
                        break;
                    case "Time.TimeFormat":
                        pv.PropertyValue = GetTimeFormat(username, isAuthenticated);
                        break;
                    case "Time.DateFormat":
                        pv.PropertyValue = GetDateFormat(username, isAuthenticated);
                        break;
                    case "Time.TimeZone":
                        pv.PropertyValue = GetTimeZone(username, isAuthenticated);
                        break;
                    case "Contact.Url":
                        pv.PropertyValue = GetUrl(username, isAuthenticated);
                        break;
                    case "Contact.Email":
                        pv.PropertyValue = GetEmail(username, isAuthenticated);
                        break;
                    case "Forum.Title":
                        pv.PropertyValue = GetTitle(username, isAuthenticated);
                        break;
                    
                    case "Forum.IsLockedOut":
                        pv.PropertyValue = GetLockedOut(username, isAuthenticated);
                        break;
                    default:
                        throw new ProviderException("Unsupported property.");
                }

                svc.Add(pv);
            }

            UpdateActivityDates(username, isAuthenticated, true);

            return svc;
        }


        public override void SetPropertyValues(SettingsContext context, SettingsPropertyValueCollection propCollection)
        {
            string UserName = (string)context["UserName"];
            bool IsAuthenticated = (bool)context["IsAuthenticated"];
            
            string UserId = GetUniqueID(UserName, IsAuthenticated, true);
            
            if (UserId == "")
                throw(new Exception("No users were found."));

            foreach (SettingsPropertyValue PropValue in propCollection)
            {
                switch (PropValue.Property.Name)
                {
                    case "Personal.Location":
                        SetLocation(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Personal.Registered":
                        SetRegistered(UserId, (DateTime)PropValue.PropertyValue);
                        break;
                    case "Personal.Language":
                        SetLanguage(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Personal.RealName":
                        SetRealName(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Personal.Signature":
                        SetSignature(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Time.TimeFormat":
                        SetTimeFormat(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Time.DateFormat":
                        SetDateFormat(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Time.TimeZone":
                        SetTimeZone(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Contact.Url":
                        SetUrl(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Contact.Email":
                        SetEmail(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Forum.Title":
                        SetTitle(UserId, (string)PropValue.PropertyValue);
                        break;
                    case "Forum.IsLockedOut":
                        SetLockedOut(UserId, (bool)PropValue.PropertyValue);
                        break;
                    default:
                        throw new ProviderException("Unsupported property.");
                }
            }

            UpdateActivityDates(UserName, IsAuthenticated, false);
        }

        private void UpdateActivityDates(string username, bool isAuthenticated, bool activityOnly)
        {
            DateTime activityDate = DateTime.Now;

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand();
            cmd.Connection = conn;

            if (activityOnly)
            {
                cmd.CommandText = "UPDATE Users Set LastActivityDate = ? " +
                      "WHERE Username = ? AND ApplicationName = ? AND IsOnline = ?";
                cmd.Parameters.Add("@LastActivityDate", OdbcType.DateTime).Value = activityDate;
                cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
                cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;
                cmd.Parameters.Add("@IsOnline", OdbcType.Bit).Value = isAuthenticated;

            }
            else
            {
                cmd.CommandText = "UPDATE Users Set LastActivityDate = ?, LastUpdatedDate = ? " +
                      "WHERE UserName = ? AND ApplicationName = ? AND IsOnline = ?";
                cmd.Parameters.Add("@LastActivityDate", OdbcType.DateTime).Value = activityDate;
                cmd.Parameters.Add("@LastUpdatedDate", OdbcType.DateTime).Value = activityDate;
                cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
                cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;
                cmd.Parameters.Add("@IsOnline", OdbcType.Bit).Value = isAuthenticated;
            }

            try
            {
                conn.Open();

                cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "UpdateActivityDates");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }
        }
        
        #region Get/Set Property
        private string GetLanguage(string username, bool isAuthenticated)
        {
            string Language = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Language FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                Language = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return Language;
        }
        private void SetLanguage(string uniqueID, string language)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET Language =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@Language", OdbcType.VarChar, 50).Value = language;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }

        private string GetTimeZone(string username, bool isAuthenticated)
        {
            string TimeZone = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT TimeZone FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                TimeZone = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return TimeZone;
        }
        private void SetTimeZone(string uniqueID, string timezone)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET TimeZone =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@TimeZone", OdbcType.VarChar).Value = timezone;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }


        private string GetUrl(string username, bool isAuthenticated)
        {
            string Url = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Url FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;
            
            try
            {
                conn.Open();

                object oUrl = cmd.ExecuteScalar();
                Url = (oUrl == DBNull.Value) ? "" : (string)oUrl;
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return Url;
        }
        private void SetUrl(string uniqueID, string url)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET Url =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@Url", OdbcType.VarChar, 50).Value = (url == null) ? "" : url;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }

        private string GetLocation(string username, bool isAuthenticated)
        {
            string Location = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Location FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                Location = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return Location;
        }
        private void SetLocation(string uniqueID, string location)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET Location =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@Location", OdbcType.VarChar, 30).Value = location;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }
        
        private bool GetLockedOut(string username, bool isAuthenticated)
        {
            bool IsLockedOut = false;

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT IsLockedOut FROM Users " +
                                    "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();
                if (ConfigurationManager.AppSettings["IsMySQL"].ToLower() == "true")
                {
                    ///MySQL
                   OdbcDataReader reader = cmd.ExecuteReader();
                    
                    if ((reader.HasRows == true) && (reader.GetString(0) == "\0"))
                        IsLockedOut = false;
                    else
                        IsLockedOut = true;
                }
                else
                {
                    //Other DB 
                    IsLockedOut = Convert.ToBoolean(cmd.ExecuteScalar());
                }

            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return IsLockedOut;
        }
        private void SetLockedOut(string uniqueID, bool islockedout)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE Users SET IsLockedOut =? WHERE UserId=?", Conn);
            
            Cmd.Parameters.Add("@IsLockedOut", OdbcType.Bit).Value = islockedout;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }
        
        private DateTime GetRegistered(string username, bool isAuthenticated)
        {
            DateTime CreationDate;

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT CreationDate FROM Users " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                CreationDate = Convert.ToDateTime(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return CreationDate;
        }
        private void SetRegistered(string uniqueID, DateTime registered)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE Users SET CreationDate =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@CreationDate", OdbcType.DateTime).Value = registered;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID.ToString();

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }

        private string GetRealName(string username, bool isAuthenticated)
        {
            string RealName = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT RealName FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                RealName = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return RealName;
        }
        private void SetRealName(string uniqueID, string realname)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET RealName =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@RealName", OdbcType.VarChar, 50).Value = realname;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }

        private string GetSignature(string username, bool isAuthenticated)
        {
            string Signature = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Signature FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();
                
                Signature = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return Signature;
        }
        private void SetSignature(string uniqueID, string signature)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET Signature =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@Signature", OdbcType.VarChar, 10).Value = signature;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }

        private string GetTimeFormat(string username, bool isAuthenticated)
        {
            string TimeFormat = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT TimeFormat FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                TimeFormat = (string)cmd.ExecuteScalar();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return TimeFormat;
        }
        private void SetTimeFormat(string uniqueID, string timeformat)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET TimeFormat =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@TimeFormat", OdbcType.VarChar, 10).Value = (timeformat == null) ? "" : timeformat;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }

        private string GetDateFormat(string username, bool isAuthenticated)
        {
            string DateFormat = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT DateFormat FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                DateFormat = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return DateFormat;
        }
        private void SetDateFormat(string uniqueID, string dateformat)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET DateFormat =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@DateFormat", OdbcType.VarChar, 10).Value = dateformat;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID.ToString();

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }
        
        private string GetTitle(string username, bool isAuthenticated)
        {
            string Title = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT UTitle FROM UsersInfo " +
                  "INNER JOIN Users ON Users.UserId = UsersInfo.UserId " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                Title = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return Title;
        }
        private void SetTitle(string uniqueID, string title)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE UsersInfo SET UTitle =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@UTitle", OdbcType.VarChar, 10).Value = title;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }

        private string GetEmail(string username, bool isAuthenticated)
        {
            string Email = "";

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT Email FROM Users " +
                  "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();

                Email = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Can not get property.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return Email;
        }
        private void SetEmail(string uniqueID, string email)
        {
            OdbcConnection Conn = new OdbcConnection(connectionString);
            OdbcCommand Cmd = new OdbcCommand("UPDATE Users SET Email =? WHERE UserId=?", Conn);

            Cmd.Parameters.Add("@Email", OdbcType.VarChar, 50).Value = email;
            Cmd.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            try
            {
                Conn.Open();
                Cmd.ExecuteNonQuery();
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "Property is not set.");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                Conn.Close();
            }
        }


        #endregion

        private string GetUniqueID(string username, bool isAuthenticated, bool ignoreAuthenticationType)
        {
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT UserId FROM Users " +
                    "WHERE UserName = ? AND ApplicationName = ?", conn);
            cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;

            if (!ignoreAuthenticationType)
            {
                cmd.CommandText += " AND IsOnline = ?";
                cmd.Parameters.Add("@IsOnline", OdbcType.Bit).Value = isAuthenticated;
            }

            string uniqueID = "";
            OdbcDataReader reader = null;

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
                if (reader.HasRows)
                    uniqueID = reader.GetString(0);
                
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "GetUniqueID");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                conn.Close();
            }

            return uniqueID;
        }

        public override int DeleteProfiles(ProfileInfoCollection profiles)
        {
            int deleteCount = 0;

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcTransaction tran = null;

            try
            {
                conn.Open();
                tran = conn.BeginTransaction();

                foreach (ProfileInfo p in profiles)
                {
                    if (DeleteProfile(p.UserName, conn, tran))
                        deleteCount++;
                }

                tran.Commit();
            }
            catch (Exception e)
            {
                try
                {
                    tran.Rollback();
                }
                catch
                {
                }

                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "DeleteProfiles(ProfileInfoCollection)");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return deleteCount;
        }

        public override int DeleteProfiles(string[] usernames)
        {
            int deleteCount = 0;

            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcTransaction tran = null;

            try
            {
                conn.Open();
                tran = conn.BeginTransaction();

                foreach (string user in usernames)
                {
                    if (DeleteProfile(user, conn, tran))
                        deleteCount++;
                }

                tran.Commit();
            }
            catch (Exception e)
            {
                try
                {
                    tran.Rollback();
                }
                catch
                {
                }

                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "DeleteProfiles(String())");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                conn.Close();
            }

            return deleteCount;
        }

        public override int DeleteInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT UserName FROM Profiles " +
                    "WHERE ApplicationName = ? AND " +
                    " LastActivityDate <= ?", conn);
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;
            cmd.Parameters.Add("@LastActivityDate", OdbcType.DateTime).Value = userInactiveSinceDate;

            switch (authenticationOption)
            {
                case ProfileAuthenticationOption.Anonymous:
                    cmd.CommandText += " AND IsOnline = ?";
                    cmd.Parameters.Add("@IsOnline", OdbcType.Bit).Value = true;
                    break;
                case ProfileAuthenticationOption.Authenticated:
                    cmd.CommandText += " AND IsOnline = ?";
                    cmd.Parameters.Add("@IsOnline", OdbcType.Bit).Value = false;
                    break;
                default:
                    break;
            }

            OdbcDataReader reader = null;
            string usernames = "";

            try
            {
                conn.Open();

                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    usernames += reader.GetString(0) + ",";
                }
            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "DeleteInactiveProfiles");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }

                conn.Close();
            }

            if (usernames.Length > 0)
            {
                usernames = usernames.Substring(0, usernames.Length - 1);
            }


            return DeleteProfiles(usernames.Split(','));
        }

      
        private bool DeleteProfile(string username, OdbcConnection conn, OdbcTransaction tran)
        {
            string uniqueID = GetUniqueID(username, false, true);

            OdbcCommand cmd1 = new OdbcCommand("DELETE * FROM Users WHERE UserId = ?", conn);
            cmd1.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;
            
            OdbcCommand cmd2 = new OdbcCommand("DELETE * FROM UsersInfo WHERE UserId = ?", conn);
            cmd2.Parameters.Add("@UserId", OdbcType.VarChar).Value = uniqueID;

            cmd1.Transaction = tran;
            cmd2.Transaction = tran;
            

            int numDeleted = 0;

            numDeleted += cmd1.ExecuteNonQuery();
            numDeleted += cmd2.ExecuteNonQuery();
            
            if (numDeleted == 0)
                return false;
            else
                return true;
        }

        
        public override ProfileInfoCollection FindProfilesByUserName(
          ProfileAuthenticationOption authenticationOption,
          string usernameToMatch,
          int pageIndex,
          int pageSize,
          out int totalRecords)
        {
            CheckParameters(pageIndex, pageSize);

            return GetProfileInfo(authenticationOption, usernameToMatch,
                null, pageIndex, pageSize, out totalRecords);
        }


        public override ProfileInfoCollection FindInactiveProfilesByUserName(
          ProfileAuthenticationOption authenticationOption,
          string usernameToMatch,
          DateTime userInactiveSinceDate,
          int pageIndex,
          int pageSize,
          out int totalRecords)
        {
            CheckParameters(pageIndex, pageSize);

            return GetProfileInfo(authenticationOption, usernameToMatch, userInactiveSinceDate,
                  pageIndex, pageSize, out totalRecords);
        }


        public override ProfileInfoCollection GetAllProfiles(
          ProfileAuthenticationOption authenticationOption,
          int pageIndex,
          int pageSize,
          out int totalRecords)
        {
            CheckParameters(pageIndex, pageSize);

            return GetProfileInfo(authenticationOption, null, null,
                  pageIndex, pageSize, out totalRecords);
        }


        public override ProfileInfoCollection GetAllInactiveProfiles(
          ProfileAuthenticationOption authenticationOption,
          DateTime userInactiveSinceDate,
          int pageIndex,
          int pageSize,
          out int totalRecords)
        {
            CheckParameters(pageIndex, pageSize);

            return GetProfileInfo(authenticationOption, null, userInactiveSinceDate,
                  pageIndex, pageSize, out totalRecords);
        }


        public override int GetNumberOfInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            int inactiveProfiles = 0;

            ProfileInfoCollection profiles =
              GetProfileInfo(authenticationOption, null, userInactiveSinceDate,
                  0, 0, out inactiveProfiles);

            return inactiveProfiles;
        }


        private void CheckParameters(int pageIndex, int pageSize)
        {
            if (pageIndex < 0)
                throw new ArgumentException("Page index must 0 or greater.");
            if (pageSize < 1)
                throw new ArgumentException("Page size must be greater than 0.");
        }


        private ProfileInfoCollection GetProfileInfo(
          ProfileAuthenticationOption authenticationOption,
          string usernameToMatch,
          object userInactiveSinceDate,
          int pageIndex,
          int pageSize,
          out int totalRecords)
        {
            OdbcConnection conn = new OdbcConnection(connectionString);
            OdbcCommand cmd = new OdbcCommand("SELECT COUNT(*) FROM Users WHERE ApplicationName = ? ", conn);
            cmd.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;


            OdbcCommand cmd2 = new OdbcCommand("SELECT UserName, LastActivityDate, LastUpdatedDate, " +
                    "IsOnline FROM Users WHERE ApplicationName = ? ", conn);
            cmd2.Parameters.Add("@ApplicationName", OdbcType.VarChar, 255).Value = ApplicationName;



            if (usernameToMatch != null)
            {
                cmd.CommandText += " AND UserName LIKE ? ";
                cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = usernameToMatch;

                cmd2.CommandText += " AND UserName LIKE ? ";
                cmd2.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = usernameToMatch;
            }


            if (userInactiveSinceDate != null)
            {
                cmd.CommandText += " AND LastActivityDate <= ? ";
                cmd.Parameters.Add("@LastActivityDate", OdbcType.DateTime).Value = (DateTime)userInactiveSinceDate;

                cmd2.CommandText += " AND LastActivityDate <= ? ";
                cmd2.Parameters.Add("@LastActivityDate", OdbcType.DateTime).Value = (DateTime)userInactiveSinceDate;
            }


            switch (authenticationOption)
            {
                case ProfileAuthenticationOption.Anonymous:
                    cmd.CommandText += " AND IsOnline = ?";
                    cmd.Parameters.Add("@IsOnline", OdbcType.Bit).Value = true;
                    cmd2.CommandText += " AND IsOnline = ?";
                    cmd2.Parameters.Add("@IsOnline", OdbcType.Bit).Value = true;
                    break;
                case ProfileAuthenticationOption.Authenticated:
                    cmd.CommandText += " AND IsOnline = ?";
                    cmd.Parameters.Add("@IsOnline", OdbcType.Bit).Value = false;
                    cmd2.CommandText += " AND IsOnline = ?";
                    cmd2.Parameters.Add("@IsOnline", OdbcType.Bit).Value = false;
                    break;
                default:
                    break;
            }


            OdbcDataReader reader = null;
            ProfileInfoCollection profiles = new ProfileInfoCollection();

            try
            {
                conn.Open();
                totalRecords = (int)cmd.ExecuteScalar();
                if (totalRecords <= 0) { return profiles; }
                if (pageSize == 0) { return profiles; }

                reader = cmd2.ExecuteReader();

                int counter = 0;
                int startIndex = pageSize * (pageIndex - 1);
                int endIndex = startIndex + pageSize - 1;

                while (reader.Read())
                {
                    if (counter >= startIndex)
                    {
                        ProfileInfo p = GetProfileInfoFromReader(reader);
                        profiles.Add(p);
                    }

                    if (counter >= endIndex)
                    {
                        cmd.Cancel();
                        break;
                    }

                    counter++;
                }

            }
            catch (OdbcException e)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "GetProfileInfo");
                    throw new ProviderException(exceptionMessage);
                }
                else
                {
                    throw e;
                }
            }
            finally
            {
                if (reader != null) { reader.Close(); }

                conn.Close();
            }

            return profiles;
        }

        private ProfileInfo GetProfileInfoFromReader(OdbcDataReader reader)
        {
            string username = reader.GetString(0);

            DateTime lastActivityDate = new DateTime();
            if (reader.GetValue(1) != DBNull.Value)
                lastActivityDate = reader.GetDateTime(1);

            DateTime lastUpdatedDate = new DateTime();
            if (reader.GetValue(2) != DBNull.Value)
                lastUpdatedDate = reader.GetDateTime(2);

            bool IsOnline = reader.GetBoolean(3);

            ProfileInfo p = new ProfileInfo(username,
                IsOnline, lastActivityDate, lastUpdatedDate, 0);

            return p;
        }


        private void WriteToEventLog(Exception e, string action)
        {
            EventLog log = new EventLog();
            log.Source = eventSource;
            log.Log = eventLog;

            string message = "An exception occurred while communicating with the data source.\n\n";
            message += "Action: " + action + "\n\n";
            message += "Exception: " + e.ToString();

            log.WriteEntry(message);
        }
    }
}
