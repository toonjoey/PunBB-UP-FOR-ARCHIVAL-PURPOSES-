﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
using System;
using System.Collections.Generic;
using System.Web;
using System.Reflection;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PunBB.Helpers
{
    public class ExtendClass : Attribute
    {
        protected String _ExtClass;

        public ExtendClass(String ClassToExtend)
        {
            _ExtClass = ClassToExtend;
        }

        public String ClassToExtend
        {
            get { return _ExtClass; }
            set { _ExtClass = value; }
        }
    }

    public class ExtendControl : Attribute
    {
        protected String _ExtControl;

        public ExtendControl(String ControlToExtend)
        {
            _ExtControl = ControlToExtend;
        }

        public String ControlToExtend
        {
            get { return _ExtControl; }
            set { _ExtControl = value; }
        }
    }

    public class HandleEvent : Attribute
    {
        protected String _ExtEvent;

        public HandleEvent(String EventToHandle)
        {
            _ExtEvent = EventToHandle;
        }

        public String EventToHandle
        {
            get { return _ExtEvent; }
            set { _ExtEvent = value; }
        }
    }

    public partial class Extension
    {
        public Extension(object Instance)
        {
            ControlCollection Controls = null;

            if (Instance.GetType().BaseType.Name != typeof(PunMasterPage).BaseType.Name)
                Controls = ((PunPage)Instance).Form.Controls;

            if (Instance.GetType().BaseType.Name == typeof(PunMasterPage).BaseType.Name)
                Controls = ((PunMasterPage)Instance).Controls;

            if (Controls != null)
                ExtendPage(Instance, Controls);
            else
                throw new SystemException("This object cannot be extended.");

        }

        public void ExtendPage(object Instance, ControlCollection Controls)
        {
            String FullClassName = Instance.GetType().BaseType.FullName;
            
            MethodInfo[] Methods = this.GetType().GetMethods();
            foreach (MethodInfo Meth in Methods)
            {
                Dictionary<string, string> Attr = GetPunAttributes(Meth);
                if (Attr["ExtendClass"] == FullClassName)
                {

                    if (Attr["ExtendControl"] == null)
                    {
                        EventInfo hEvent = Instance.GetType().BaseType.GetEvent(Attr["HandleEvent"]);
                        if (hEvent != null)
                        {
                            Delegate Handler = Delegate.CreateDelegate(hEvent.EventHandlerType, null, Meth);
                            hEvent.AddEventHandler(Instance, Handler);
                        }
                    }
                    else
                    {
                        foreach (Control Ctrl in Controls)
                        {
                            if (Ctrl.ID == Attr["ExtendControl"])
                            {
                                EventInfo hEvent = Ctrl.GetType().GetEvent(Attr["HandleEvent"]);
                                if (hEvent != null)
                                {
                                    Delegate Handler = Delegate.CreateDelegate(hEvent.EventHandlerType, null, Meth);
                                    hEvent.AddEventHandler(Ctrl, Handler);
                                }
                            }
                        }
                    }
                }
            }
        }

        public Dictionary<string, string> GetPunAttributes(MethodInfo Method)
        {
            Dictionary<string, string> Return = new Dictionary<string, string>(3);
            string Value = "";
            Attribute Attr = null;

            Attr = Attribute.GetCustomAttribute(Method, typeof(ExtendClass));
            if (Attr != null)
            {
                Value = ((ExtendClass)Attr).ClassToExtend;
                if (Value != null)
                    Return.Add("ExtendClass", Value);
            }
            else
            {
                Return.Add("ExtendClass", Value);
            }

            Attr = Attribute.GetCustomAttribute(Method, typeof(ExtendControl));
            if (Attr != null)
            {
                Value = ((ExtendControl)Attr).ControlToExtend;
                if (Value != null)
                    Return.Add("ExtendControl", Value);
            }
            else
            {
                Return.Add("ExtendControl", null);
            }

            Attr = Attribute.GetCustomAttribute(Method, typeof(HandleEvent));
            if (Attr != null)
            {
                Value = ((HandleEvent)Attr).EventToHandle;
                if (Value != null)
                    Return.Add("HandleEvent", Value);
            }
            else
            {
                Return.Add("HandleEvent", null);
            }
 
            return Return;
        }
    }
}