﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Web;
using PunBB.Helpers;
using System.Data.Odbc;
using System.Configuration;
using System.Diagnostics;

namespace PunBB
{
    public class PunPage : System.Web.UI.Page
    {
        public ConnectionStringSettingsCollection _connections = ConfigurationManager.ConnectionStrings;
        public OdbcConnection _connection = new OdbcConnection();
        public Extension _extension;

        public string eventSource = "PunBB.NET";
        private string eventLog = "Application";

        public void WriteToEventLog(Exception e, string action)
        {
            EventLog PunLog = new EventLog();
            PunLog.Source = eventSource;
            PunLog.Log = eventLog;

            string message = "Action: " + action + "\n\n";
            message.Insert(message.Length, "Exception: " + e.Message);

            PunLog.WriteEntry(message);
        }
    }
}