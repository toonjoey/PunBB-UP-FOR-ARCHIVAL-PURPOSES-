﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Web;
using PunBB.Helpers;

namespace PunBB
{
    /// <summary>
    /// Summary description for PunMasterPage
    /// </summary>
    public class PunMasterPage : System.Web.UI.MasterPage
    {
        public Extension _extension;
    }
}