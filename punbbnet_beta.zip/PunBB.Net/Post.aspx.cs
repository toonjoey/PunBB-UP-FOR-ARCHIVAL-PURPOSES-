﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.Configuration;
using System.Web.Hosting;
using PunBB.Helpers;
using System.Data.Odbc;

public partial class Post : PunBB.PunPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        _extension = new Extension(this);
        _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
        tbPost.Focus();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string UserName = Page.User.Identity.Name;
        string TopicSubjectText = tbPost.Text;
        string UserId = string.Empty;
        int CurTopicId = 0;
        int CurPostId = 0;
        Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
        OdbcConnection conn = new OdbcConnection(_connection.ConnectionString);

        #region In this section we get user's Id acording to his name and calculate TopicId fr the topic being created .
        OdbcCommand cmd = new OdbcCommand("SELECT Users.UserId FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Users " +" WHERE UserName = ? ", conn);
        cmd.Parameters.Add("@UserName", OdbcType.VarChar, 255).Value = UserName;

        OdbcCommand cmd2 = new OdbcCommand("SELECT MAX(Posts.Pid) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Posts ", conn);

        OdbcDataReader reader = null;

        try
        {
            conn.Open();

            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                UserId= reader.GetString(0);
            }

            reader = cmd2.ExecuteReader();
            while (reader.Read())
            {
                CurPostId = Convert.ToInt32(reader.GetString(0));
            }
        }
        catch (OdbcException ex)
        {
                throw ex;        
        }
        finally
        {
            if (reader != null) { reader.Close(); }
            conn.Close();
        }

        #endregion

        #region Insert Values about new Topic into Data Base 

        cmd = new OdbcCommand("INSERT INTO " + Config.AppSettings.Settings["TablePrefix"].Value + "Posts " +
                " (UserId, Pid, UserIp, Message, Posted, Edited, EditedBy, Tid) " +
                " Values(?, ?, ?, ?, ?, ?, ?, ?)", conn);

        cmd.Parameters.Add("@UserId", OdbcType.VarChar, 255).Value = UserId;
        cmd.Parameters.Add("@Pid", OdbcType.Int).Value = CurPostId+1;
        cmd.Parameters.Add("@UserIp", OdbcType.VarChar, 255).Value = Request.UserHostAddress.ToString();
        cmd.Parameters.Add("@Message", OdbcType.VarChar, 255).Value = tbPost.Text;
        cmd.Parameters.Add("@Posted", OdbcType.DateTime).Value = System.DateTime.Now;
        cmd.Parameters.Add("@Edited", OdbcType.DateTime).Value = System.DateTime.Now;
        cmd.Parameters.Add("@EditedBy", OdbcType.VarChar, 255).Value = UserName;
        cmd.Parameters.Add("@Tid", OdbcType.VarChar, 255).Value = Request.QueryString["Topic"];



        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        catch (OdbcException ex)
        {
            throw ex;
        }
        finally
        {
            conn.Close();
        }
        #endregion

        Response.Redirect("~/ViewTopic.aspx?Topic=" + Request.QueryString["Topic"] + "&Forum=" + Request.QueryString["Forum"]);
    }
}
