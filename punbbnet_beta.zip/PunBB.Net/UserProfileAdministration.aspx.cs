﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;

namespace PunBB
{
    public partial class UserProfileAdministration : PunBB.PunPage
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            
            if (User.IsInRole("Moderator") == false)
                Response.Redirect(SiteMap.RootNode.Url);

            
            if (IsPostBack == false)
            {
                ProfileCommon UserInfo = GetProfile();

                if (UserInfo.Contact.Email != "")
                    IsLockedOut.Checked = UserInfo.Forum.IsLockedOut;
                else
                    Response.Redirect(SiteMap.RootNode.Url);
            }
        }

        protected void btnUpdate_Click(Object sender, EventArgs e)
        {
            ProfileCommon UserInfo = GetProfile();
            UserInfo.Forum.IsLockedOut = IsLockedOut.Checked;
			UserInfo.Save();
        }

        protected ProfileCommon GetProfile()
        {
            ProfileCommon UserInfo = Profile;
            if (Request.QueryString["UserName"] != null)
                UserInfo = Profile.GetProfile(Request.QueryString["UserName"]);
            
            return UserInfo;
        }
    }
}