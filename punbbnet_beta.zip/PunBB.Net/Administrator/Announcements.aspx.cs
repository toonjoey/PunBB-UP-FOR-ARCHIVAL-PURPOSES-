﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;
using System.Web.Configuration;
using System.Web.Hosting;

namespace PunBB
{
    public partial class Administrator_Announcements : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;

            if (IsPostBack == false)
            {
                txtAnnouncement.Text = ConfigurationManager.AppSettings["Announcement"];
            }
        }
        protected void SaveChanges_Click(object sender, EventArgs e)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            Config.AppSettings.Settings["Announcement"].Value = "<h1 class=\"hn\"><span>" + txtAnnouncementHeading.Text + "</span></h1><br><div class=\"content\">" + txtAnnouncement.Text + "</div>";
            if(chbEnableAnnouncement.Checked)
                Config.AppSettings.Settings["AnnouncementEnabled"].Value = "true";
            else
                Config.AppSettings.Settings["AnnouncementEnabled"].Value = "false";
            Config.Save();
        }
}
}
