﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
using System;
//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;
using System.Web.Configuration;
using System.Web.Hosting;

namespace PunBB
{
    public partial class Administrator_Setup : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            
            if (IsPostBack == false)
            {
                txtBoardTitle.Text = ConfigurationManager.AppSettings["BoardTitle"];
                txtBoardDescription.Text = ConfigurationManager.AppSettings["BoardDescription"];
                txtTopicsOnPage.Text = ConfigurationManager.AppSettings["TopicsOnPage"];
                txtPostsOnPage.Text = ConfigurationManager.AppSettings["PostsOnPage"];
                //txtAnnouncement.Text = ConfigurationManager.AppSettings["Announcement"];
                //cbAuthorizedUserList.Checked = Convert.ToBoolean(ConfigurationManager.AppSettings["ShowAuthorizedUserList"]);
                //cbMarkForum.Checked = Convert.ToBoolean(ConfigurationManager.AppSettings["MarkForum"]);
                //cbMarkTopic.Checked = Convert.ToBoolean(ConfigurationManager.AppSettings["MarkTopic"]);
                //cbShowUserInfo.Checked = Convert.ToBoolean(ConfigurationManager.AppSettings["ShowUserInfo"]);
                //cbShowPostCount.Checked = Convert.ToBoolean(ConfigurationManager.AppSettings["ShowPostCount"]);
            }
            
        }
        protected void btnUpdateSettings_Click(object sender, EventArgs e)
        {
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            
            Config.AppSettings.Settings["BoardTitle"].Value = txtBoardTitle.Text;
            Config.AppSettings.Settings["BoardDescription"].Value = txtBoardDescription.Text;
            Config.AppSettings.Settings["TopicsOnPage"].Value = txtTopicsOnPage.Text;
            Config.AppSettings.Settings["PostsOnPage"].Value = txtPostsOnPage.Text;
            //Config.AppSettings.Settings["Announcement"].Value = txtAnnouncement.Text;
            //Config.AppSettings.Settings["ShowAuthorizedUserList"].Value = cbAuthorizedUserList.Checked.ToString();
            //Config.AppSettings.Settings["MarkForum"].Value = cbMarkForum.Checked.ToString();
            //Config.AppSettings.Settings["MarkTopic"].Value = cbMarkTopic.Checked.ToString();
            //Config.AppSettings.Settings["ShowUserInfo"].Value = cbShowUserInfo.Checked.ToString();
            //Config.AppSettings.Settings["ShowPostCount"].Value = cbShowPostCount.Checked.ToString();
            
            Config.Save();
        }
}
}