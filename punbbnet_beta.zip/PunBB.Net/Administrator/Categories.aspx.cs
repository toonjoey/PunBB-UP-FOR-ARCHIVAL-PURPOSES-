﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3

using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.Odbc;
using System.Web.Hosting;
using System.Web.Configuration;
using PunBB.Helpers;
using System.Data.SqlClient;

namespace PunBB
{
    public partial class Administrator_Categories : PunBB.PunPage
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            hlForums.NavigateUrl = "~/Administrator/Forum.aspx";
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            CategoryDataSource.ConnectionString = _connection.ConnectionString;
            if (IsPostBack == false)
            {
                CategoryDataSource.SelectCommand = "SELECT Cname, Cid FROM Categories";
                drDownLstCategory.DataTextField = "Cname";
                drDownLstCategory.DataValueField = "Cid";
                drDownLstCategory.DataBind();


                String Cmd = "SELECT Cid, Cname, DispPosition FROM Categories";
                SqlDataSource Data = new SqlDataSource("System.Data.Odbc", _connection.ConnectionString, Cmd);

                lstEditCategories.DataSource = Data;
                lstEditCategories.DataBind();
            }
       
        }


        /// <summary>
        /// Checks if new category has a unique name
        /// </summary>
        /// <param name="CatName">Name to be checked for uniqueness</param>
        /// <param name="conn">OdbcConnection</param>
        /// <param name="Config">Configuration file</param>
        /// <returns></returns>
        private bool CheckCatNameUniqueness(string CatName, OdbcConnection conn)
        {
            #region Check if category has a new (unique) name
            bool result = true;
            Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
            OdbcDataReader reader = null;
            OdbcCommand cmdGetAllCatNames = new OdbcCommand("SELECT Categories.Cname FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Categories ", conn);
            try
            {
                conn.Open();
                OdbcDataAdapter DataAdapter = new OdbcDataAdapter(cmdGetAllCatNames);
                DataSet myDataSet = new DataSet();
                DataAdapter.Fill(myDataSet);
                for (int i = 0; i < myDataSet.Tables[0].Rows.Count; i++)
                {
                    DataRow row = myDataSet.Tables[0].Rows[i];
                    try
                    {
                        if ((String)row["Cname"] == CatName)
                        {
                            result = false;
                            return result;
                        }
                    }
                    catch
                    {
                        result = false;
                    }

                }
                return result;

            }
            catch (OdbcException ex)
            {
                throw ex;
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                conn.Close();
            }

            #endregion
        }


        protected void btnAddCategory_Click(object sender, EventArgs e)
        {
            ErrorBox.Text = "";
            if (Page.IsValid)
            {
                string categoryName = tbCategoryName.Text;
                int Position = 0;
                int Cid = 0;
                if (tbCategoryPosition.Text != String.Empty)
                    Position = Convert.ToInt32(tbCategoryPosition.Text);
                Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
                OdbcConnection conn = new OdbcConnection(_connection.ConnectionString);
                OdbcDataReader reader = null;

                if (CheckCatNameUniqueness(categoryName, conn))
                {
                    #region get the last CID from the DB in irder to calculate the next one
                    OdbcCommand cmdGetId = new OdbcCommand("SELECT MAX(Categories.Cid) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Categories ", conn);
                    try
                    {
                        conn.Open();

                        reader = cmdGetId.ExecuteReader();
                        if (reader.HasRows)
                        {
                            object Value = reader.GetValue(0);
                            if (Value is DBNull)
                            {
                                Cid = 0;
                            }
                            else
                            {
                                Cid = Convert.ToInt32(Value);
                            }
                        }
                        else
                        {
                            Cid = 0;
                        }

                    }
                    catch (OdbcException ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (reader != null) { reader.Close(); }
                        conn.Close();
                    }

                    #endregion

                    #region Insert Values about new category into Data Base
                    OdbcCommand cmd = new OdbcCommand("INSERT INTO " + Config.AppSettings.Settings["TablePrefix"].Value + "Categories " +
                            " (Cid, Cname, DispPosition) " +
                            " Values(?, ?, ?)", conn);

                    cmd.Parameters.Add("@Cid", OdbcType.Int, 255).Value = Cid + 1;
                    cmd.Parameters.Add("@Cname", OdbcType.VarChar, 255).Value = categoryName;
                    cmd.Parameters.Add("@DispPosition", OdbcType.Int).Value = Position;

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (OdbcException ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        conn.Close();
                    }
                    #endregion
                }
                else
                {
                    ErrorBox.Text = Resources.AdminResource.txtCatNameNotUnque;
                }

            }
        }

        protected void valCategoryName_ServerValidate(object source, ServerValidateEventArgs args)
        {
            args.IsValid = true;

            if (args.Value == "")
            {
                args.IsValid = false;
                valCategoryName.ErrorMessage = "Имя категории не должно быть пустым";
            }
        }



        protected void Button1_Click(object sender, EventArgs e)
        {
            DeleteCategory(Convert.ToInt32(drDownLstCategory.SelectedItem.Value));
        }

        private void DeleteCategory(int Cid)
        {
            OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);
            DeleteChildCategories(Cid);

            #region Delete all realted to the category information (Forums, Topics, Posts, etc.)
            
            ArrayList FidList = new ArrayList();
            #region Getting Forums Id Where Category Id = Cid
            
            try
            {
                OdbcCommand cmdGetFids = new OdbcCommand("Select Fid FROM Forums WHERE Cid=?", Conn);
                cmdGetFids.Parameters.Add("@Cid", OdbcType.Int).Value=Cid;

                Conn.Open();
                OdbcDataAdapter DataAdapter = new OdbcDataAdapter(cmdGetFids);
                OdbcCommandBuilder myCommandBuilder = new OdbcCommandBuilder(DataAdapter);
                DataSet myDataSet = new DataSet();
                DataAdapter.Fill(myDataSet);
                for (int i = 0; i < myDataSet.Tables[0].Rows.Count; i++)
                {
                    DataRow row = myDataSet.Tables[0].Rows[i];
                    try
                    {
                        FidList.Add((int)row["Fid"]);
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }

                }
 
            }
            catch (OdbcException e)
            {    
                throw e;
            }
            finally
            {
                Conn.Close();
            }
            #endregion

            ArrayList TidList = new ArrayList();
            #region Getting Topic Ids Where ForumId belongs to one in the FidList Array List
            foreach (int Fid in FidList)
            {
                try
                {
                    OdbcCommand cmdGetTids = new OdbcCommand("Select Tid FROM Topics WHERE Fid=?", Conn);
                    cmdGetTids.Parameters.Add("@Fid", OdbcType.Int).Value = Fid;

                    Conn.Open();
                    OdbcDataAdapter DataAdapter = new OdbcDataAdapter(cmdGetTids);
                    OdbcCommandBuilder myCommandBuilder = new OdbcCommandBuilder(DataAdapter);
                    DataSet myDataSet = new DataSet();
                    DataAdapter.Fill(myDataSet);
                    for (int i = 0; i < myDataSet.Tables[0].Rows.Count; i++)
                    {
                        DataRow row = myDataSet.Tables[0].Rows[i];
                        try
                        {
                            TidList.Add((int)row["Tid"]);
                        }
                        catch (Exception e)
                        {
                            throw e;
                        }

                    }

                }
                catch (OdbcException e)
                {
                    throw e;
                }
                finally
                {
                    Conn.Close();
                }
            }
            #endregion

            ArrayList PidList = new ArrayList();
            #region Getting Post Ids Where Topic Id belongs to one in the TidList Array List
            foreach (int Tid in TidList)
            {
                try
                {
                    OdbcCommand cmdGetPids = new OdbcCommand("Select Pid FROM Posts WHERE Tid=?", Conn);
                    cmdGetPids.Parameters.Add("@Tid", OdbcType.Int).Value = Tid;

                    Conn.Open();
                    OdbcDataAdapter DataAdapter = new OdbcDataAdapter(cmdGetPids);
                    OdbcCommandBuilder myCommandBuilder = new OdbcCommandBuilder(DataAdapter);
                    DataSet myDataSet = new DataSet();
                    DataAdapter.Fill(myDataSet);
                    for (int i = 0; i < myDataSet.Tables[0].Rows.Count; i++)
                    {
                        DataRow row = myDataSet.Tables[0].Rows[i];
                        try
                        {
                            PidList.Add((int)row["Pid"]);
                        }
                        catch (Exception e)
                        {
                            throw e;
                        }

                    }

                }
                catch (OdbcException e)
                {
                    throw e;
                }
                finally
                {
                    Conn.Close();
                }
            }
            #endregion

            #region Delete data from Reports and searchMatches accroding to PostId
            foreach (int PostId in PidList)
            {
                OdbcCommand cmdDelFromReports = new OdbcCommand("DELETE FROM Reports WHERE Pid=?", Conn);
                cmdDelFromReports.Parameters.Add("@Pid", OdbcType.Int).Value = PostId;
                OdbcCommand cmdDelFromSearchMatches = new OdbcCommand("DELETE FROM SearchMatches WHERE Pid=?", Conn);
                cmdDelFromSearchMatches.Parameters.Add("@Pid", OdbcType.Int).Value = PostId;
                Conn.Open();
                cmdDelFromReports.ExecuteNonQuery();
                cmdDelFromSearchMatches.ExecuteNonQuery();
                Conn.Close();
            }
            #endregion

            #region Delete Data from Subscriptions and Posts according to TopicId
            foreach (int TopicId in TidList)
            {
                OdbcCommand cmdDelFromSubscriptions = new OdbcCommand("DELETE FROM Subscriptions WHERE Tid=?", Conn);
                cmdDelFromSubscriptions.Parameters.Add("@Tid", OdbcType.Int).Value = TopicId;
                OdbcCommand cmdDelFromPosts = new OdbcCommand("DELETE FROM Posts WHERE Tid=?", Conn);
                cmdDelFromPosts.Parameters.Add("@Tid", OdbcType.Int).Value = TopicId;
                Conn.Open();
                cmdDelFromSubscriptions.ExecuteNonQuery();
                cmdDelFromPosts.ExecuteNonQuery();
                Conn.Close();
            }
            #endregion

            #region Delete data from Topics according to ForumId
            foreach (int ForumId in FidList)
            {
                OdbcCommand cmdDelFromTopics = new OdbcCommand("DELETE FROM Topics WHERE Fid=?", Conn);
                cmdDelFromTopics.Parameters.Add("@Fid", OdbcType.Int).Value = ForumId;
                Conn.Open();
                cmdDelFromTopics.ExecuteNonQuery();
                Conn.Close();
            }
            #endregion

            #region Delete data from Forums according to CategoryId
            OdbcCommand cmdDelFromForums = new OdbcCommand("DELETE FROM Forums WHERE Cid=?", Conn);
            cmdDelFromForums.Parameters.Add("@Cid", OdbcType.Int).Value = Cid;
            Conn.Open();
            cmdDelFromForums.ExecuteNonQuery();
            Conn.Close();
            #endregion


            #endregion

            #region delete the category itself
            OdbcCommand cmd = new OdbcCommand("DELETE FROM Categories WHERE Cid=?", Conn);
            cmd.Parameters.Add("@Cid", OdbcType.Int).Value = Cid;
            Conn.Open();
            cmd.ExecuteNonQuery();
            Conn.Close();
            #endregion

        }

        private void DeleteChildCategories(int Scid)
        {
            OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);
            OdbcCommand cmd = new OdbcCommand("Select Cid FROM Categories WHERE ScId=?", Conn);
            cmd.Parameters.Add("@ScId", OdbcType.Int).Value = Scid;
            Int32 Cid = 0;
            OdbcDataReader reader = null;
            try
            { 
                Conn.Open();

                //reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
                OdbcDataAdapter DataAdapter = new OdbcDataAdapter(cmd);
               
                OdbcCommandBuilder myCommandBuilder = new OdbcCommandBuilder(DataAdapter);
                DataSet myDataSet = new DataSet();
                DataAdapter.Fill(myDataSet);
                for (int i = 0; i < myDataSet.Tables[0].Rows.Count; i++)
                {
                    DataRow row = myDataSet.Tables[0].Rows[i];
                    try
                    {
                        Cid = (int)row["Cid"];
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }

                    DeleteCategory(Convert.ToInt32(Cid));
                }
 
            }
            catch (OdbcException e)
            {    
                throw e;
            }
            finally
            {
                if (reader != null) { reader.Close(); }
                Conn.Close();
            }
        }

        protected void drDownLstCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            string index = drDownLstCategory.SelectedItem.Value;
        }


        protected void Button2_Click(object sender, EventArgs e)
        {
            OdbcConnection Conn = new OdbcConnection(_connection.ConnectionString);
            for(int i=0; i<lstEditCategories.Items.Count;i++)
            {
                TextBox tbName = (TextBox)lstEditCategories.Items[i].FindControl("tbName");
                TextBox tbPos = (TextBox)lstEditCategories.Items[i].FindControl("tbPos");
                HiddenField hfId = (HiddenField)lstEditCategories.Items[i].FindControl("hfId");
                string NewName = tbName.Text;
                string NewPos = tbPos.Text;
                string ID = hfId.Value;
                if (CheckCatNameUniqueness(NewName, Conn))
                {
                    OdbcCommand cmdUpdateCategory = new OdbcCommand("UPDATE Categories SET Cname=?, DispPosition=? WHERE Cid = ?", Conn);
                    cmdUpdateCategory.Parameters.Add("@Cname", OdbcType.VarChar).Value = NewName;
                    cmdUpdateCategory.Parameters.Add("@DispPosition", OdbcType.Int).Value = Convert.ToInt32(NewPos);
                    cmdUpdateCategory.Parameters.Add("@Cid", OdbcType.Int).Value = Convert.ToInt32(ID);
                    Conn.Open();
                    cmdUpdateCategory.ExecuteNonQuery();
                    Conn.Close();
                }
                else
                {
                    ErrorBox.Text = Resources.AdminResource.txtCatNameNotUnque + " (" + NewName + ")"+"\n";
                }
            }
        }
}
}
