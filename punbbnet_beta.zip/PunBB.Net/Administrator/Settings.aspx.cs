﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PunBB
{
    public partial class Administator_Settings : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Redirect("~/Administrator/Groups.aspx");
        }
    }
}