﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PunBB.Helpers;
using System.Configuration;
using System.Web.Configuration;
using System.Web.Hosting;


namespace PunBB
{
    public partial class Administrator_AdminMasterPage : PunBB.PunMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}