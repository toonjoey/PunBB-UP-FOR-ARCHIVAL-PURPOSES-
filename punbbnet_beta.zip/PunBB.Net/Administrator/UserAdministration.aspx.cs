﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;

namespace PunBB
{
    public partial class Administrator_UserAdministration : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
        }
        
        protected void btnCreateUser_Click(object sender, EventArgs e)
        {
            Membership.CreateUser(txtUserName.Text, txtUserPassword1.Text, txtUserEmail.Text);
        }
        
        protected void btnDeleteUser_Click(object sender, EventArgs e)
        {
            Membership.DeleteUser(txtDeleteUser.Text, true);
            txtDeleteUser.Text = "";
        }
}
}