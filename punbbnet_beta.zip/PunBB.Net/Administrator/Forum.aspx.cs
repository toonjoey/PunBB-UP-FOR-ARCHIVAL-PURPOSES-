﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using PunBB.Helpers;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.Odbc;
using System.Web.Hosting;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace PunBB
{
    public partial class Administrator_Forum : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            CategoryDataSource.ConnectionString = _connection.ConnectionString;
            if (IsPostBack == false)
            {
                CategoryDataSource.SelectCommand = "SELECT Cname, Cid FROM Categories";
                drDownLstCategory.DataTextField = "Cname";
                drDownLstCategory.DataValueField = "Cid";
                drDownLstCategory.DataBind();
            }
            ErrorBox.Visible = false;
        }


        protected void btnAddForum_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {

                string ForumName = tbForumName.Text;
                int Fid = 0;
                int Position = 0;
                if (tbPosition.Text != String.Empty)
                    Position = Convert.ToInt32(tbPosition.Text);
                int Cid = Convert.ToInt32(drDownLstCategory.SelectedItem.Value);

                Configuration Config = WebConfigurationManager.OpenWebConfiguration(HostingEnvironment.ApplicationVirtualPath);
                OdbcConnection conn = new OdbcConnection(_connection.ConnectionString);
                OdbcDataReader reader = null;
                #region get the last FID from the DB in order to calculate the next one
                OdbcCommand cmdGetId = new OdbcCommand("SELECT MAX(Forums.Fid) FROM " + Config.AppSettings.Settings["TablePrefix"].Value + "Forums ", conn);
                try
                {
                    conn.Open();

                    reader = cmdGetId.ExecuteReader();
                    if (reader.HasRows)
                    {
                        object Value = reader.GetValue(0);
                        if (Value is DBNull)
                        {
                            Fid = 0;
                        }
                        else
                        {
                            Fid = Convert.ToInt32(Value);
                        }
                    }
                    else
                    {
                        Fid = 0;
                    }
                }
                catch (OdbcException ex)
                {
                    throw ex;
                }
                finally
                {
                    if (reader != null) { reader.Close(); }
                    conn.Close();
                }

                #endregion

                #region Insert Values about new Forum into Data Base
                OdbcCommand cmd = new OdbcCommand("INSERT INTO " + Config.AppSettings.Settings["TablePrefix"].Value + "Forums " +
                        " (Fid, Fname, DispPosition, Cid) " +
                        " Values(?, ?, ?, ?)", conn);

                cmd.Parameters.Add("@Fid", OdbcType.VarChar, 255).Value = Fid+1;
                cmd.Parameters.Add("@Fname", OdbcType.VarChar, 255).Value = ForumName;
                cmd.Parameters.Add("@DispPosition", OdbcType.Int).Value = Position;
                cmd.Parameters.Add("@Cid", OdbcType.Int).Value = Cid;

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (OdbcException ex)
                {
                    throw ex;
                }
                finally
                {
                    conn.Close();
                }
                #endregion
            }
        }



        protected void valFName_ServerValidate(object source, ServerValidateEventArgs args)
        {
             args.IsValid = true;

             if (args.Value == "")
             {
                 args.IsValid = false;
                 ltrError.Text = Resources.AdminResource.errEmptyForumName;
                 ErrorBox.Visible = true;
             }
            OdbcConnection conn = new OdbcConnection(_connection.ConnectionString);
            OdbcCommand Select = new OdbcCommand("select Fname FROM Forums WHERE Cid=?;", conn);
            Select.Parameters.Add("@Cid", OdbcType.Int).Value = drDownLstCategory.SelectedItem.Value;
            OdbcDataAdapter Adapter = new OdbcDataAdapter(Select);
            DataSet Set = new DataSet();
            Adapter.Fill(Set);
            foreach (DataRow DRow in Set.Tables[0].Rows)
            {
                if(DRow["Fname"].ToString()==args.Value)
                {
                    args.IsValid=false;
                    ltrError.Text =Resources.AdminResource.errUniqueForumName ;
                    ErrorBox.Visible = true;
                    break;
                }
            }
        }
}
}
