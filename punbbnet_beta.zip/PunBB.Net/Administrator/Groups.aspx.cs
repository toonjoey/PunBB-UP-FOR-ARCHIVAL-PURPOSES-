﻿//Copyright (C) 2009 PunBB
//http://www.gnu.org/licenses/gpl.html GPL version 3
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PunBB.Helpers;
using System.Data.Odbc;

namespace PunBB
{
    public partial class Administrator_Groups : PunBB.PunPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _extension = new Extension(this);
            _connection.ConnectionString = _connections["PunConnectionString"].ConnectionString;
            
            if (IsPostBack == false)
                UpdateRolesList();
            
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            String Role = txtGroup.Text;
            if ((txtGroup.Text != "") && (Roles.RoleExists(Role) == false))
            {
                Roles.CreateRole(Role);
                UpdateRolesList();
            }
        }
        
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            String Role = lstGroups.SelectedValue;

            if ((Role != "Administrator") && (Role != "Moderator") && (Role != "Member"))
            {
                Roles.DeleteRole(Role);
                UpdateRolesList();
            }
        }

        protected void btnAddUser_Click(object sender, EventArgs e)
        {
            if ((txtAddUser.Text != "") && (Membership.FindUsersByName(txtAddUser.Text).Count != 0))
            {
                try
                {
                    Roles.AddUserToRole(txtAddUser.Text, lstAddUser.SelectedValue);
                }
                catch (Exception ex)
                {
                    ErrorBox.Text = ex.Message;
                }
            }
        }

        protected void btnRemoveUser_Click(object sender, EventArgs e)
        {
            if ((txtRemoveUser.Text != "") && (Membership.FindUsersByName(txtRemoveUser.Text).Count != 0))
            {
                try
                {
                    Roles.RemoveUserFromRole(txtRemoveUser.Text, lstRemoveUser.SelectedValue);
                }
                catch (Exception ex)
                {
                    ErrorBox.Text = ex.Message;
                }
            }
        }

        private void UpdateRolesList()
        {
            String[] Groups = Roles.GetAllRoles();
            lstGroups.Items.Clear();
            lstAddUser.Items.Clear();
            lstRemoveUser.Items.Clear();

            foreach (String RoleName in Groups)
            {
                lstGroups.Items.Add(new ListItem(RoleName));
                lstAddUser.Items.Add(new ListItem(RoleName));
                lstRemoveUser.Items.Add(new ListItem(RoleName));
            }
        }
}
}